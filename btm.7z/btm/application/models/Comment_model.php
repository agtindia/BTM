<?php

defined('BASEPATH') OR exit('No direct script access allowed');  

/* Comment Model Class */

class Comment_model extends CI_model
{

    /* Loading Parent Construct */

    function __construct()  
    {  
      parent::__construct();
    }

    /* Insert Comment Into Database */

    public function insert($comment)
    {
      $this->db->insert('comments', $comment);
    }

    /* Get Comment For Requested Task */

    public function get_comment($id)
    {
      $this->db->select('*');
      $this->db->from('comments');
      $this->db->where(array('task_id'=>$id,'type'=>'comment'));
      $query=$this->db->get();
      return $query;
    }

    /* Get Comments For Employees */

    public function get($name)
    {
      $this->db->select('*');
      $this->db->from('comments');
      $this->db->where('current',$name);
      $this->db->order_by("comment_id", "desc");
      $query=$this->db->get();
      return $query;
    }

    /* Get All Comments */

    public function get_all()
    {
      $this->db->select('*');
      $this->db->from('comments');
      $this->db->order_by("comment_id", "desc");
      $query=$this->db->get();
      return $query;
    }

}

?>