<?php

defined('BASEPATH') OR exit('No direct script access allowed');  

/* Assign Model Class */


class Assign_model extends CI_model{

    /* Loading Parent Construct */

    function __construct()  
    {  
      parent::__construct();
    }

    /* Get User Data From User Table */

    public function fetchtable()
    {
      $query = $this->db->get('user');  
      return $query;
    }

    /* Get All Categories From Categories Table */

    public function get_categories()
    {
      $query = $this->db->get('categories');  
      return $query;
    }

    /* Insert Task Into 'issues' Database */

    public function assign_task($task)
    {
      $query=$this->db->insert('issues', $task);
      return $query;
    }

    public function get_last_row()
    {
      $this->db->select('*');
      $this->db->from('issues');
      $this->db->order_by('id','DESC');
      $this->db->limit(1);
      $query=$this->db->get();
      return $query;
    }

}

?>
