
<?php $role=$this->session->userdata('user_role'); ?>
<div class="brand-logo">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="company-name">AGT India
                </div>
                <div class="company-app">Task Management</div>
              </div>
            </div>  
          </div>
        </div>
        <div class="navigation">
          <ul>

            <li <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ; 
if($url==$_SERVER['SERVER_NAME'].'/user'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url(); ?>">
                <span class="navigation-icon">
                  <i class="fa fa-tachometer" aria-hidden="true"></i>
                </span>
                <span class="navigation-label">Dashboard</span>
              </a>
            </li>

            <li  <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ;
if($url==$_SERVER['SERVER_NAME'].'/notifications'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('notifications'); ?>">
                <span class="navigation-icon">
                  <i class="fa fa-bell-o" aria-hidden="true"></i>
                </span>
                <span class="navigation-label">Notifications</span>
              </a>
            </li>

            <li  <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ;
if($url==$_SERVER['SERVER_NAME'].'/assign'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('assign'); ?>">
                <span class="navigation-icon">
                  <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                </span>
                <span class="navigation-label">Assign Task</span>
              </a>
            </li>

            <li  <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ;
if($url==$_SERVER['SERVER_NAME'].'/assign'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('auto'); ?>">
                <span class="navigation-icon">
                  <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                </span>
                <span class="navigation-label">Auto Populate Tasks</span>
              </a>
            </li>

            <?php if($role=='admin' || $role=='manager') { ?>
            <li <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ; 
if($url==$_SERVER['SERVER_NAME'].'/register'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('register'); ?>">
                <span class="navigation-icon">
                  <i class="fa fa-users" aria-hidden="true"></i>
                  </i>
                </span>
                <span class="navigation-label">Employees</span>
              </a>
            </li>

            <?php } if($role=='admin') { ?>
            <li <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ; 
if($url==$_SERVER['SERVER_NAME'].'/report'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('report'); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-signal">
                  </i>
                </span>
                <span class="navigation-label">Report</span>
              </a>
            </li>

            <?php } if($role=='admin') { ?>
            <li <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ; 
if($url==$_SERVER['SERVER_NAME'].'/categories'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('categories'); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-list-alt">
                  </i>
                </span>
                <span class="navigation-label">Categories</span>
              </a>
            </li>

            <?php } ?>
            <li <?php
$url=$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'] ; 
if($url==$_SERVER['SERVER_NAME'].'/profile'){?> class="active" <?php } ?> >
              <a href="<?php echo site_url('profile'); ?>">
                <span class="navigation-icon">
                  <i class="fa fa-user-circle" aria-hidden="true"></i>
                </span>
                <span class="navigation-label">Profile</span>
              </a>
            </li>

            <li>
              <a href="<?php echo base_url('logout'); ?>" onclick="return confirm('Are you sure to logout?');">
                <span class="navigation-icon">
                  <i class="fa fa-sign-out" aria-hidden="true"></i>
                </span>
                <span class="navigation-label">Logout</span>
              </a>
            </li>

          </ul>
        </div>