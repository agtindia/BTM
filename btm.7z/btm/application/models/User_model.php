<?php

defined('BASEPATH') OR exit('No direct script access allowed');  

/* User Model Class */

class User_model extends CI_model{

/* Derive Parent Classes from Libraries */

function __construct()  
{  
  parent::__construct();  
} 

/* Function for Register User into 'user' database */

public function register_user($user)
{

$this->db->insert('user', $user);

}

/* Login Function */

public function login_user($uname,$pass)
{
  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_name',$uname);
  $this->db->where('user_password',$pass);

  if($query=$this->db->get())
  {
      return $query->row_array();
  }
  else
  {
    return false;
  }

}

/* Check E-mail is Exist or Not while submit Register Form */

public function email_check($email)
{

  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('user_email',$email);
  $query=$this->db->get();

  if($query->num_rows()>0)
  {
    return false;
  }
  else
  {
    return true;
  }

}

/* get User Email */

public function get_email($name)
{

  $this->db->select('*');
  $this->db->from('user');
  $this->db->where('name',$name);
  $query=$this->db->get();
  return $query;

}

/* Get User Table Values From Database */

function fetchtable()
{
  $query = $this->db->get('user');
  return $query;
}

/* Add New Category */

public function add_category($category)
{
  $this->db->insert('categories', $category);
}

/* Get Tasks Assigned for Current User */

public function data()
{
  $user_name=$this->session->userdata('name');
  $this->db->select('*');
  $this->db->from('issues');
  $this->db->where('assigned_to',$user_name);
  $this->db->order_by("id", "desc");
  $query=$this->db->get();
  return $query;
}

/* Get All Tasks From Database  */

public function all()
{
  $this->db->select('*');
  $this->db->from('issues');
  $this->db->order_by("id", "desc");
  $query = $this->db->get();  
  return $query;
}

/* Get All Tasks Assigned By Current User  */

public function me()
{
  $user_name=$this->session->userdata('name');
  $this->db->select('*');
  $this->db->from('issues');
  $this->db->where('assigned_by',$user_name);
  $this->db->order_by("id", "desc");
  $query=$this->db->get();
  return $query;
}

/* Get All Tasks those are Resolved */

public function resolved()
{
  $resolve = "resolved";
  $this->db->select('*');
  $this->db->from('issues');
  $this->db->where('status',$resolve);
  $this->db->order_by("id", "desc");
  $query = $this->db->get();
  return $query;
}

/* Get All Resolved Tasks that Assigned To Current User */

public function emp_resolved($name)
{
  $resolve = "resolved";
  $this->db->select('*');
  $this->db->from('issues');
  $this->db->where('status',$resolve);
  $this->db->where('assigned_to',$name);
  $this->db->order_by("id", "desc");
  $query = $this->db->get();
  return $query;
}

/* Delete Requested task from Table */

public function delete($id)
{
  $this->db->where('id', $id);
  $this->db->delete('issues');
}

}


?>
