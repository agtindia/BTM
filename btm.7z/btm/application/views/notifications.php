<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8">     
    </script>  
  </head>  
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <!-- Storing User Role From Session Data In Role Variable -->
    <?php
$role=$this->session->userdata('user_role');
$this->load->helper('form');
$name=$this->session->userdata('name');
?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <!-- View Tasks Assigned To Current User -->
          <div class="row">
            <div class="col-md-1">
            </div>
            <div class="col-md-10">
              <div class="panel-register panel-primary">
                <div class="panel-heading">  
                  <div class="row">
                    <div class="col-md-8"> 
                      <h3 class="panel-title"> 
                        <i class="fa fa-bell" aria-hidden="true"></i> Notifications
                      </h3>
                    </div>
                  </div>
                </div>
                <div class="body">
                  <div class="table-responsive "> 
                    <table class="table table-bordered">
                      <?php $role=$this->session->userdata('user_role'); ?>
                      <?php 
if($role=="employee")                   
{ 
foreach ($cm->result() as $cmt)                     
{ 
$ato=$cmt->current;
?>
                      <!-- Notifications for employees -->

                      <tr class="cmt">
                        <td>
                          <div class="row">
                            <?php $type=$cmt->type; if($type=="comment" && $ato==$name) { ?>
                            <div class="col-md-1">
                              <i class="fa fa-commenting">
                              </i>
                            </div>
                            <?php } elseif($type=="resolved" && $ato==$name) { ?>
                            <div class="col-md-1">
                              <span class="glyphicon resolve glyphicon-ok">
                              </span>
                            </div>
                            <?php } elseif($type=="closed" && $ato==$name) { ?>
                            <div class="col-md-1">
                              <i class="fa fa-power-off" aria-hidden="true">
                              </i>
                            </div>
                            <?php } elseif($type=="change" && $ato==$name) { ?>
                            <div class="col-md-1">
                              <i class="fa fa-exchange" aria-hidden="true">
                              </i>
                            </div>
                            <?php } elseif($type=="task" && $ato==$name) { ?>
                            <div class="col-md-1">
                              <span class="glyphicon glyphicon-plus-sign">
                                </i>
                            </div>
                            <?php } ?>
                            <div class="col-md-11">
                              <?php if($type=="comment" && $ato==$name){ ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?>
                              Commented On Task
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time">
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="resolved" && $ato==$name) { ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                              Resolved The Task
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time">
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="closed" && $ato==$name) { ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                              Closed The Task
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time">
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="change" && $ato==$name) { ?>
                              <?php echo $cmt->publisher_name; ?> Changed Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a> 
                              To 
                              <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time">
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="task" && $ato==$name) { ?>
                              <?php echo $cmt->publisher_name; ?> Assigned Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a> 
                              To 
                              <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time">
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } ?>
                            </div>
                          </div>
                        </td>    
                      </tr>

                      <!-- Notifications for Admin, Manager -->

                      <?php } } else { foreach ($ca->result() as $cmt) { ?>
                      <tr class="cmt">
                        <td>
                          <div class="row">
                            <?php $type=$cmt->type; if($type=="comment") { ?>
                            <div class="col-md-1">
                              <i class="fa fa-commenting">
                              </i>
                            </div>
                            <?php } elseif($type=="resolved") { ?>
                            <div class="col-md-1">
                              <span class="glyphicon resolve glyphicon-ok">
                                </div>
                              <?php } elseif($type=="closed") { ?>
                              <div class="col-md-1">
                                <i class="fa fa-power-off" aria-hidden="true">
                                </i>
                              </div>
                              <?php } elseif($type=="change") { ?>
                              <div class="col-md-1">
                                <i class="fa fa-exchange" aria-hidden="true">
                                </i>
                              </div>
                              <?php } else { ?>
                              <div class="col-md-1">
                                <span class="glyphicon glyphicon-plus-sign">
                                  </i>
                              </div>
                              <?php } ?>
                              <div class="col-md-11">
                                <?php if($type=="comment"){ ?>
                                <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?>
                                Commented On Task
                                <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                  <?php echo $cmt->task_id; ?>
                                </a>
                                <br>
                                <i class="ace-icon fa fa-clock-o bigger-110">
                                </i> 
                                <span class="time">
                                  <?php echo $cmt->at; ?>
                                </span>
                                <?php } elseif($type=="resolved") { ?>
                                <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                                Resolved The Task
                                <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                  <?php echo $cmt->task_id; ?>
                                </a>
                                <br>
                                <i class="ace-icon fa fa-clock-o bigger-110">
                                </i> 
                                <span class="time">
                                  <?php echo $cmt->at; ?>
                                </span>
                                <?php } elseif($type=="closed") { ?>
                                <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                                Closed The Task
                                <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                  <?php echo $cmt->task_id; ?>
                                </a>
                                <br>
                                <i class="ace-icon fa fa-clock-o bigger-110">
                                </i> 
                                <span class="time">
                                  <?php echo $cmt->at; ?>
                                </span>
                                <?php } elseif($type=="change") { ?>                      
                                <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?> 
                                Changed Task 
                                <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                  <?php echo $cmt->task_id; ?>
                                </a> To 
                                <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                                <br>
                                <i class="ace-icon fa fa-clock-o bigger-110">
                                </i> 
                                <span class="time">
                                  <?php echo $cmt->at; ?>
                                </span>
                                <?php } else { ?>                      
                                <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?> 
                                Assigned Task 
                                <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                  <?php echo $cmt->task_id; ?>
                                </a> To 
                                <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                                <br>
                                <i class="ace-icon fa fa-clock-o bigger-110">
                                </i> 
                                <span class="time">
                                  <?php echo $cmt->at; ?>
                                </span>
                                <?php } ?>
                              </div>
                            </div>
                            </td>    
                      </tr>
                      <?php } } ?>
                    </table>        
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-1">
            </div>
          </div>
        </div>
      </aside>
    </article>
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
</html>
