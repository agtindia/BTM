<?php

defined('BASEPATH') OR exit('No direct script access allowed');  

class Task_model extends CI_model{

    function __construct()  
    {  
      parent::__construct();

    }

    /* Get Task Details With The ID */

    public function fetch_task($id)
    {
  		$this->db->select('*');
  		$this->db->from('issues');
  		$this->db->where('id',$id);
  		$query=$this->db->get();

      if($query->num_rows()>0)
      {
        return $query;
      }
      else
      {
        return false;
      }
    }

    /* Update Task */

    public function update_task($id,$task_info)
    {
      	$this->db->where('id', $id);
      	$query=$this->db->update('issues', $task_info);

      	if($query)
      	{
       		return true;
      	}
      	else
      	{
       		return false;
      	}    	
    }

    /* Get Tasks assigned to current User */

    public function to()
    {
        $user_name=$this->session->userdata('name');
        $this->db->select('*');
        $this->db->from('issues');
        $this->db->where('assigned_to',$user_name);
        $this->db->order_by("id", "desc");
        $query=$this->db->get();
        return $query;
    }

    /* Get All Tasks For Admin  */

    public function all()
    {
        $this->db->select('*');
        $this->db->from('issues');
        $this->db->order_by("id", "desc");
        $query = $this->db->get();  
        return $query;
    }

    /* Get All Tasks Assigned By Current User  */

    public function me()
    {
        $user_name=$this->session->userdata('name');
        $this->db->select('*');
        $this->db->from('issues');
        $this->db->where('assigned_by',$user_name);
        $this->db->order_by("id", "desc");
        $query=$this->db->get();
        return $query;
    }

    /* Get All Tasks those are Resolved */

    public function resolved()
    {
        $resolve = "resolved";
        $this->db->select('*');
        $this->db->from('issues');
        $this->db->where('status',$resolve);
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query;
    }

    /* Assign begin time of task */

    public function begin($id,$info)
    {   
        $this->db->where(array('id'=>$id, 'start'=>'-'));
        $this->db->update('issues', $info);
    }
	
	/* Assign finish time of task */
	
    public function end($id,$info)
    {   
        $this->db->where(array('id'=>$id, 'end'=>'-'));
        $this->db->update('issues', $info);
    }
	
	/* Search Results Based On Input Key */
	
    public function search_task($key)
    {   
		  $this->db->select('*');
      $this->db->from('issues');
      $this->db->like('id', $key);
		  $this->db->or_like('title', $key);
      $this->db->or_like('assigned_to', $key);
      $query = $this->db->get();
		  return $query;
    }
	
	/* Search Results For Employees */
	
    public function search_emp($key,$name)
    {   
		  $this->db->select('*');
      $this->db->from('issues');				
      $this->db->like('id', $key);				
		  $this->db->where('assigned_to', $name);
		  $this->db->or_like('title', $key);		
		  $this->db->where('assigned_to', $name);
      $query = $this->db->get();
		  return $query;
    }



}

?>
