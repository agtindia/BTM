<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller 
{



        public function __construct()
        {
            parent::__construct();
            $this->load->helper('form');
            $this->load->model('profile_model');
            $this->load->library('form_validation');
        }

        /* View Current User Details and Update Page  */

        public function index()
        {
            $id=$this->session->userdata('user_id');
            $data['u']=$this->profile_model->fetchuser($id);
        	$this->load->view('profile', $data);
        }

        /* View User Update Page  */

        public function profile_user()
        {
            $id=$this->input->get('id');
            $data['up']=$this->profile_model->fetchuser($id);
            $this->load->view('profile_user', $data);
        }

        /* Update Current User Details  */

        public function update_profile()
        {
            $id=$this->session->userdata('user_id');
            $user_info = array(
                    'name' => $this->input->post('name'),
                    'user_name' => $this->input->post('usr_name'),
                    'user_email' => $this->input->post('email'),
                    'user_mobile' => $this->input->post('mobile'),
                    );
            $update=$this->profile_model->update_profile($id,$user_info);

            if($update)
            {
                $this->session->set_flashdata('success', 'Profile Updated Successfully...');
                redirect('profile');
            }
            else
            {
                $this->session->set_flashdata('error', 'Update Profile Failed...');
                redirect('profile');
            }
        }

        /* Update Requested User Details  */

        public function update_user_profile()
        {
            $id=$this->input->post('id');
            $user_info = array(
                    'name' => $this->input->post('name'),
                    'user_name' => $this->input->post('usr_name'),
                    'user_email' => $this->input->post('email'),
                    'user_mobile' => $this->input->post('mobile'),
                    );
            $update=$this->profile_model->update_profile($id,$user_info);

            if($update)
            {
                $this->session->set_flashdata('success', ' '.$user_info['name'].' Profile Updated Successfully...');
                redirect('profile_user?id='.$id);
            }
            else
            {
                $this->session->set_flashdata('error', ' '.$user_info['name'].' Update Profile Failed...');
                redirect('profile_user?id='.$id);
            }
        }

        /* Update Current User Password  */

        public function update_password()
        {
            $id=$this->session->userdata('user_id');

            $user_password = array('user_password'=>md5($this->input->post('new_password')));

            $old1 = md5($this->input->post('old_password'));

            $user = $this->profile_model->old_password();

            foreach($user->result() as $pwd) 
            {
                $old=$pwd->user_password;
            }

            if($old1==$old)
            {
                $this->profile_model->update_password($id,$user_password);
                $this->session->set_flashdata('password_success', 'Password Updated Successfully...');
                redirect('profile');
            }

            else
            {
                $this->session->set_flashdata('password_error', 'Incorrect Old Password...');
                redirect('profile');
            }
      
        }

        /* Update Requested User Password  */

        public function update_user_password()
        {
            $id=$this->input->post('id');

            $user_password = array('user_password'=>md5($this->input->post('new_password')));

            $pwd=$this->profile_model->update_password($id,$user_password);

            if($pwd)
            {                
                $this->session->set_flashdata('password_success', ' Password Updated Successfully...');
                redirect('profile_user?id='.$id);
            }

            else
            {
                $this->session->set_flashdata('password_error', ' Password Update Failed...');
                redirect('profile_user?id='.$id);
            }
      
        }

}

?>