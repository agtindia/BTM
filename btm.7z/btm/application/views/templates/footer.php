<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<footer>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">Copyright 2017 @ <a href="http://agtindia.com/" class="link" target="_blank">AGT INDIA</a></div>
    </div>
  </div>
</footer>
