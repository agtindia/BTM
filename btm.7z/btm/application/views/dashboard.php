<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System </title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  </head>
  <body>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
    <!-- Getting session data's -->
    <?php 
$role=$this->session->userdata('user_role'); 
$name=$this->session->userdata('name');
$this->load->helper('form'); 
?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <!-- View Tasks Assigned To Current User -->
          <div class="row">
            <div class="col-md-8">
            </div>
            <div class="col-md-4">
              <?php if($role=="employee") { ?>
              <form method="GET" action="search_task" autocomplete="off">
                <?php } else { ?>
                <form method="GET" action="search" autocomplete="off">
                  <?php } ?>
                  <div class="input-group dashboard-search">
                    <input type="text" class="form-control" placeholder="Search..." name="q">
                    <div class="input-group-btn">
                      <button class="btn btn-warning" type="submit">
                        <i class="glyphicon glyphicon-search"></i>
                      </button>
                    </div>
                  </div>
                </form>
            </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register info panel-primary">
                  <div class="panel-heading">
                    <h3 class="panel-title">Assigned To Me
                    </h3> 
                    <a href="to" class="view-all-btn" data-toggle="tooltip" Title="View All">View All
                    </a>  
                  </div>
                  <div class="body text-center">
                    <div class="table-responsive">
                      <table id="export_table" class="table table-bordered">
                        <tr>
                          <th class="text-center">ID
                          </th>
                          <th class="text-center">Title
                          </th>
                          <th class="text-center">Category
                          </th>
                          <th class="text-center">At
                          </th>
                          <th class="text-center">By
                          </th>
                          <th class="text-center">Status
                          </th>
                          <th class="text-center">Due Date
                          </th>
                          <th class="text-center">
                          </th>
                        </tr>
                        <?php foreach ($t->result() as $i => $task) 
                        { 
                          $status=$task->status;
                          $category=$task->category;
                          $by=$task->assigned_by;
                        ?>
                        <?php if($role!="admin") { if($category=="Self Tasks"&&$by==$name) { ?>
                        <tr>
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $task->category; ?>
                          </td>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_by; ?>
                          </td>
                          <td>
                            <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <a href="update?id=<?php echo $task->id ?>">
                              <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                              </button>
                            </a>
                        </td>
                      </tr>
                      <?php } else { ?>
                        <tr>
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $task->category; ?>
                          </td>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_by; ?>
                          </td>
                          <td>
                            <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <a href="update?id=<?php echo $task->id ?>">
                              <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                              </button>
                            </a>
                        </td>
                      </tr>
                      <?php } } if($role=="admin") { ?>
                        <tr>
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $task->category; ?>
                          </td>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_by; ?>
                          </td>
                          <td>
                            <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <a href="update?id=<?php echo $task->id ?>">
                              <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                              </button>
                            </a>
                        </td>
                      </tr>
                    <?php } if ($i>2) break; } ?>
                    </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- All Tasks Assigned By All. Only View Permission for Admin, Manager, Reporter -->
        <?php if($role!="employee") { ?>
        <div class="row">
          <div class="col-md-12">
            <div class="panel-register-profile info panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title">All
                </h3>
                <a href="all" class="view-all-btn" data-toggle="tooltip" Title="View All">View All
                </a>
              </div>
              <div class="body">
                <div class="table-responsive">
                  <table id="export_table" class="table table-bordered text-center">
                    <tr>
                      <th class="text-center">ID
                      </th>
                      <th class="text-center">Title
                      </th>
                      <th class="text-center">Category
                      </th>
                      <th class="text-center">At
                      </th>
                      <th class="text-center">By
                      </th>
                      <th class="text-center">To
                      </th>
                      <th class="text-center">Status
                      </th>
                      <th class="text-center">Due Date
                      </th>
                      <th>
                      </th>
                    </tr>
                    <?php foreach ($a->result() as $i => $task) 
                    { 
                      $status=$task->status;
                      $category=$task->category;
                      $by=$task->assigned_by;
                    ?>
                    <?php if($role!="admin") { 
                    if($category=="Self Tasks"&&$by==$name) { ?>
                    <tr>
                      <td>
                        <?php echo $task->id; ?>
                      </td>
                      <td>
                        <a href="task_view?id=<?php echo $task->id ?>">
                          <?php echo $task->title; ?>
                        </a>
                      </td>
                      <td>
                        <?php echo $task->category; ?>
                      </td>
                      <td>
                        <?php echo $task->time; ?>
                      </td>
                      <td>
                        <?php echo $task->assigned_by; ?>
                      </td> 
                      <td>
                        <?php echo $task->assigned_to; ?>
                      </td>
                      <td>
                        <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                      </td>
                      <td>
                        <?php echo $task->due_date; ?>
                      </td>
                      <td>
                        <a href="update?id=<?php echo $task->id ?>">
                          <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                          </button>
                        </a>
                      </td>
                    </tr>
                    <?php } elseif($category!="Self Tasks") { ?>
                      <tr>
                      <td>
                        <?php echo $task->id; ?>
                      </td>
                      <td>
                        <a href="task_view?id=<?php echo $task->id ?>">
                          <?php echo $task->title; ?>
                        </a>
                      </td>
                      <td>
                        <?php echo $task->category; ?>
                      </td>
                      <td>
                        <?php echo $task->time; ?>
                      </td>
                      <td>
                        <?php echo $task->assigned_by; ?>
                      </td> 
                      <td>
                        <?php echo $task->assigned_to; ?>
                      </td>
                      <td>
                        <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                      </td>
                      <td>
                        <?php echo $task->due_date; ?>
                      </td>
                      <td>
                        <a href="update?id=<?php echo $task->id ?>">
                          <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                          </button>
                        </a>
                      </td>
                    </tr>
                    <?php } } if($role=="admin") { ?>                    
                    <tr>
                      <td>
                        <?php echo $task->id; ?>
                      </td>
                      <td>
                        <a href="task_view?id=<?php echo $task->id ?>">
                          <?php echo $task->title; ?>
                        </a>
                      </td>
                      <td>
                        <?php echo $task->category; ?>
                      </td>
                      <td>
                        <?php echo $task->time; ?>
                      </td>
                      <td>
                        <?php echo $task->assigned_by; ?>
                      </td> 
                      <td>
                        <?php echo $task->assigned_to; ?>
                      </td>
                      <td>
                        <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                      </td>
                      <td>
                        <?php echo $task->due_date; ?>
                      </td>
                      <td>
                        <a href="update?id=<?php echo $task->id ?>">
                          <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                          </button>
                        </a>
                      </td>
                    </tr>                
                    <?php } if ($i>2) break; } ?>
                  </table>
                </div>
              </div>
              <?php echo form_close(); ?>
            </div>
          </div>
        </div>
          <!-- Tasks Assigned By Current Admin or Manager, Reporter. View Permission is not for employees -->
          <?php } if($role!="employee") { ?>
          <div class="row">
            <div class="col-md-12">
              <div class="panel-register info panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">Assigned by Me
                  </h3> 
                  <a href="by" class="view-all-btn" data-toggle="Edit" Title="View All">View All
                  </a>     
                </div>
                <div class="body text-center">
                  <div class="table-responsive">
                    <table class="table table-bordered">
                      <tr>
                        <th class="text-center">ID
                        </th>
                        <th class="text-center">Title
                        </th>
                        <th class="text-center">Category
                        </th>
                        <th class="text-center">At
                        </th>
                        <th class="text-center">To
                        </th>
                        <th class="text-center">Status
                        </th>
                        <th class="text-center">Due Date
                        </th>
                        <th class="text-center">
                        </th>
                      </tr>
                      <?php foreach ($b->result() as $i => $task) { $status=$task->status; ?>
                      <tr>
                        <td>
                          <?php echo $task->id; ?>
                        </td>
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>                          
                        <td>
                          <?php echo $task->category; ?>
                        </td>                          
                        <td>
                          <?php echo $task->time; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_to; ?>
                        </td>
                        <td>
                          <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                        </td>
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>
                        <td>
                          <a href="update?id=<?php echo $task->id ?>">
                          <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                          </button>
                          </a>
                        </td>
                      </tr>
                      <?php if ($i>2) break; } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php } ?>
          <!-- View All Resolved Tasks -->
          <div class="row">
            <div class="col-md-12">
              <div class="panel-register info panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">Resolved
                  </h3> 
                  <a href="resolved" class="view-all-btn" data-toggle="tooltip" Title="View All">View All
                  </a>  
                </div>
                <div class="body">
                  <div class="table-responsive">
                    <table class="table table-bordered text-center">
                      <tr>
                        <th class="text-center">ID 
                        </th>
                        <th class="text-center">Title
                        </th>
                        <th class="text-center">Category
                        </th>
                        <th class="text-center">By
                        </th>
                        <th class="text-center">To
                        </th>
                        <th class="text-center">Created At
                        </th>
                        <th class="text-center">Start Date
                        </th>
                        <th class="text-center">Due Date
                        </th>
                        <th class="text-center">End Date
                        </th>
                      </tr>                      
                        <?php
                          $status=$task->status;
                          $category=$task->category;
                          $by=$task->assigned_by;
                        ?>
                        <?php if($role=="employee") { foreach ($er->result() as $e => $task) { ?>                      
                        <tr>  
                        <td>
                          <?php echo $task->id; ?>
                        </td>                    
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>
                        <td>
                          <?php echo $task->category; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_by; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_to; ?>
                        </td>
                        <td>
                          <?php echo $task->time; ?>
                        </td> 
                        <td>
                          <?php echo $task->start_date; ?>
                        </td>  
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>    
                        <td>
                          <?php echo $task->end_date; ?>
                        </td>
                        </tr>
                        <?php if($e>2) break; } ?>
                        <?php } elseif($role=="reporter"&&$role=="manager") { ?>
                        <?php foreach ($r->result() as $a => $task) { ?>                      
                        <?php if($category=="Self Tasks"&&$by==$name) { ?>
                        <tr>
                        <td>
                          <?php echo $task->id; ?>
                        </td> 
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>
                        <td>
                          <?php echo $task->category; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_by; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_to; ?>
                        </td>
                        <td>
                          <?php echo $task->time; ?>
                        </td>
                        <td>
                          <?php echo $task->start_date; ?>
                        </td>  
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>    
                        <td>
                          <?php echo $task->end_date; ?>
                        </td>
                      </tr>
                      <?php } else { ?>                        
                      <tr>
                        <td>
                          <?php echo $task->id; ?>
                        </td> 
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>
                        <td>
                          <?php echo $task->category; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_by; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_to; ?>
                        </td>
                        <td>
                          <?php echo $task->time; ?>
                        </td>
                        <td>
                          <?php echo $task->start_date; ?>
                        </td>  
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>    
                        <td>
                          <?php echo $task->end_date; ?>
                        </td>
                      </tr>
                      <?php } if ($a>2) break; } } else { ?>
                        <?php foreach ($r->result() as $a => $task) { ?>
                        <tr>
                        <td>
                          <?php echo $task->id; ?>
                        </td> 
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>
                        <td>
                          <?php echo $task->category; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_by; ?>
                        </td>
                        <td>
                          <?php echo $task->assigned_to; ?>
                        </td>
                        <td>
                          <?php echo $task->time; ?>
                        </td>
                        <td>
                          <?php echo $task->start_date; ?>
                        </td>  
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>    
                        <td>
                          <?php echo $task->end_date; ?>
                        </td>
                      </tr>
                      <?php  if ($a>2) break; } } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </article>      
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
  </html>
