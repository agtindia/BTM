<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System
    </title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8">    
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  </head>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <!-- Getting session data's -->
    <?php 
$role=$this->session->userdata('user_role'); 
$name=$this->session->userdata('name');
$this->load->helper('form'); 
?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <!-- View Tasks Assigned To Current User -->
          <div class="row">
            <div class="col-md-8">
            </div>
            <div class="col-md-4">
              <?php if($role=="employee") { ?>
              <form method="GET" action="search_task" autocomplete="off">
                <?php } else { ?>
                <form method="GET" action="search" autocomplete="off">
                  <?php } ?>
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search..." name="q">
                    <div class="input-group-btn">
                      <button class="btn btn-warning" type="submit">
                        <i class="glyphicon glyphicon-search">
                        </i>
                      </button>
                    </div>
                  </div>
                </form>
                </div>
            </div>
            <br>
            <div class="row">
              <div class="col-md-8">
                <div class="row">
                  <div class="col-md-12">
                    <div class="panel-register info panel-primary">
                      <div class="panel-heading">
                      	<h3 class="panel-title">Assigned To Me</h3>	
                        <a href="to" class="view-all-btn">View All</a>	
                      </div>
                      <div class="body text-center">
                        <div class="table-responsive">
                          <table id="export_table" class="table table-bordered">
                            <tr>
                              <th class="text-center">ID
                              </th>
                              <th class="text-center">Title
                              </th>
                              <th class="text-center">At
                              </th>
                              <th class="text-center">By
                              </th>
                              <th class="text-center">Status
                              </th>
                              <th class="text-center">Due Date
                              </th>
                              <th class="text-center">
                              </th>
                            </tr>
                            <?php foreach ($t->result() as $i => $task) { $status=$task->status; 
if($status!='Resolved') { ?>
                            <?php if($status=='New') { ?>
                            <tr class="link bg-danger">
                              <td>
                                <?php echo $task->id; ?>
                              </td>
                              <td>
                                <a href="task_view?id=<?php echo $task->id ?>">
                                  <?php echo $task->title; ?>
                                </a>
                              </td>
                              <?php } elseif($status=='Resolved') { ?>
                            <tr class="link bg-success">
                              <td>
                                <?php echo $task->id; ?>
                              </td>
                              <td>
                                <a href="task_view?id=<?php echo $task->id ?>">
                                  <?php echo $task->title; ?>
                                </a>
                              </td>
                              <?php } else { ?>
                            <tr class="link bg">
                              <td>
                                <?php echo $task->id; ?>
                              </td>
                              <td>
                                <a href="task_view?id=<?php echo $task->id ?>">
                                  <?php echo $task->title; ?>
                                </a>
                              </td>
                              <?php } ?>
                              <td>
                                <?php echo $task->time; ?>
                              </td>
                              <td>
                                <?php echo $task->assigned_by; ?>
                              </td>
                              <td>
                                <?php  
if($status=='New') 
{ 
echo '<p class=text-danger>'.$status.'</p>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<p class=text-primary>'.$status.'</p>'; 
}
elseif($status=='Resolved') 
{ 
echo '<p class=text-success>'.$status.'</p>'; 
}
elseif($status=='Closed') 
{ 
echo '<p class=text-secondary>'.$status.'</p>'; 
}
else 
{ 
echo '<p>'.$status.'</p>'; 
} 
?>
                              </td>
                              <td>
                                <?php echo $task->due_date; ?>
                              </td>
                              <td>
                                <a href="update?id=<?php echo $task->id ?>">
                                  <button type="button" name="update"> 
                                    <i class="fa fa-pencil pencil grey">
                                    </i>
                                  </button>
                                </a> 
                            </a>
                            </td>
                          </tr>
                        <?php } if ($i>2) break; } ?>
                        </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- All Tasks Assigned By All. Only View Permission for Admin, Manager -->
            <?php if($role!="employee") { ?>
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register info panel-primary">
                  <div class="panel-heading">
                  		<h3 class="panel-title">All</h3>	
                        <a href="all" class="view-all-btn">View All</a>	
                  </div>
                  <div class="body text-center">
                    <div class="table-responsive">
                      <table class="table table-bordered">
                        <tr>
                          <th class="text-center">ID
                          </th>
                          <th class="text-center">Title
                          </th>
                          <th class="text-center">At
                          </th>
                          <th class="text-center">By
                          </th>
                          <th class="text-center">To
                          </th>
                          <th class="text-center">Status
                          </th>
                          <th class="text-center">Due Date
                          </th>
                          <th class="text-center">
                          </th>
                        </tr>
                        <?php foreach ($a->result() as $i => $task) { $status=$task->status;
if($status!='Resolved') { ?>
                        <?php if($status=='New') { ?>
                        <tr class="link bg-danger">
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <?php } elseif($status=='Resolved') { ?>
                        <tr class="link bg-success">
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <?php } else { ?>
                        <tr class="link bg">
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <?php } ?>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_by; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_to; ?>
                          </td>
                          <td>
                            <?php 
if($status=='New') 
{ 
echo '<p class=text-danger>'.$status.'</p>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<p class=text-primary>'.$status.'</p>'; 
}
elseif($status=='Resolved') 
{ 
echo '<p class=text-success>'.$status.'</p>'; 
}
elseif($status=='Closed') 
{ 
echo '<p class=text-secondary>'.$status.'</p>'; 
}
else 
{ 
echo '<p>'.$status.'</p>'; 
} 
?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <a href="update?id=<?php echo $task->id ?>">
                              <button type="button" name="update"> 
                                <i class="fa fa-pencil pencil grey">
                                </i>
                              </button>
                            </a>
                          </td>
                        </tr>
                        <?php } if ($i>2) break; } ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Tasks Assigned By Current Admin or Manager. View Permission is not for employees -->
            <?php } if($role!="employee") { ?>
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register info panel-primary">
                  <div class="panel-heading">
                  	<h3 class="panel-title">Assigned by Me</h3>	
                    <a href="by" class="view-all-btn">View All</a>	
                  
                    
                  </div>
                  <div class="body text-center">
                    <div class="table-responsive">
                      <table class="table table-bordered">
                        <tr>
                          <th class="text-center">ID
                          </th>
                          <th class="text-center">Title
                          </th>
                          <th class="text-center">At
                          </th>
                          <th class="text-center">To
                          </th>
                          <th class="text-center">Status
                          </th>
                          <th class="text-center">Due Date
                          </th>
                          <th class="text-center">
                          </th>
                        </tr>
                        <?php foreach ($b->result() as $i => $task) { $status=$task->status; ?>
                        <?php if($status=='New') { ?>
                        <tr class="link bg-danger">
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <?php } elseif($status=='Resolved') { ?>
                        <tr class="link bg-success">
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <?php } else { ?>
                        <tr class="link bg">
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <?php } ?>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_to; ?>
                          </td>
                          <td>
                            <?php 
if($status=='New') 
{ 
echo '<p class=text-danger>'.$status.'</p>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<p class=text-primary>'.$status.'</p>'; 
}
elseif($status=='Resolved') 
{ 
echo '<p class=text-success>'.$status.'</p>'; 
}
elseif($status=='Closed') 
{ 
echo '<p class=text-secondary>'.$status.'</p>'; 
}
else 
{ 
echo '<p>'.$status.'</p>'; 
} 
?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <a href="update?id=<?php echo $task->id ?>">
                              <button type="button" name="update"> 
                                <i class="fa fa-pencil pencil grey">
                                </i>
                              </button>
                            </a>
                          </td>
                        </tr>
                        <?php if ($i>2) break; } ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
            <!-- View All Resolved Tasks -->
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register info panel-primary">
                  <div class="panel-heading">
                  		<h3 class="panel-title">Resolved</h3>	
                        <a href="resolved" class="view-all-btn">View All</a>	
                  </div>
                  <div class="body">
                    <div class="table-responsive">
                      <table class="table table-bordered text-center">
                        <tr>
                          <th class="text-center">ID
                          </th>
                          <th class="text-center">Title
                          </th>
                          <th class="text-center">Created At
                          </th>
                          <th class="text-center">Start Date
                          </th>
                          <th class="text-center">Due Date
                          </th>
                          <th class="text-center">End Date
                          </th>
                        </tr>
                        <?php foreach ($r->result() as $i => $task) { ?>
                        <tr class="link bg-success">
                          <?php if($role=="employee") { if($task->assigned_to==$name) { ?>
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->start_date; ?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <?php echo $task->end_date; ?>
                          </td>
                          <?php } } else { ?>
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->start_date; ?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <?php echo $task->end_date; ?>
                          </td>
                        </tr>
                        <?php } if ($i>2) break; } ?>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Showing Notifications -->
          <div class="col-md-4">
            <div class="panel-register panel-primary">
              <div class="panel-heading">
              		<h3 class="panel-title">Notifications</h3>	
                    <a href="notifications" class="view-all-btn">View All</a>	
              </div>
              <div class="body">
                <div class="table-responsive">
                  <table class="table table-bordered">
                    <?php $role=$this->session->userdata('user_role'); ?>
                    <?php 
if($role=="employee")                   
{ 
foreach ($cm->result() as $m => $cmt)                     
{ 
$ato=$cmt->current;
?>
                    <!-- Notifications for employees -->
                    <tr class="cmt">
                      <td>
                        <div class="row">
                          <?php $type=$cmt->type; if($type=="comment" && $ato==$name) { ?>
                          <div class="col-md-1">
                            <i class="fa fa-commenting">
                            </i>
                          </div>
                          <?php } elseif($type=="resolved" && $ato==$name) { ?>
                          <div class="col-md-1">
                            <span class="glyphicon resolve glyphicon-ok">
                            </span> 
                          </div>
                          <?php } elseif($type=="closed" && $ato==$name) { ?>
                          <div class="col-md-1">
                            <i class="fa fa-off" aria-hidden="true">
                            </i> 
                          </div>
                          <?php } elseif($type=="change" && $ato==$name) { ?>
                          <div class="col-md-1">
                            <i class="fa fa-exchange" aria-hidden="true">
                            </i> 
                          </div>
                          <?php } elseif($type=="task" && $ato==$name) { ?>
                          <div class="col-md-1">
                            <span class="glyphicon glyphicon-plus-sign">
                              </i>
                          </div>
                          <?php } ?>
                          <div class="col-md-11">
                            <?php if($type=="comment" && $ato==$name){ ?>
                            <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?>
                            Commented On Task 
                            <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                              <?php echo $cmt->task_id; ?>
                            </a>
                            <br>
                            <i class="ace-icon fa fa-clock-o bigger-110">
                            </i> 
                            <span class="time">
                              <?php echo $cmt->at; ?>
                            </span>
                            <?php } elseif($type=="resolved" && $ato==$name) { ?>
                            <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                            Resolved The Task 
                            <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                              <?php echo $cmt->task_id; ?>
                            </a>
                            <br>
                            <i class="ace-icon fa fa-clock-o bigger-110">
                            </i> 
                            <span class="time">
                              <?php echo $cmt->at; ?>
                            </span>
                            <?php } elseif($type=="closed" && $ato==$name) { ?>
                            <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                            Closed The Task 
                            <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                              <?php echo $cmt->task_id; ?>
                            </a>
                            <br>
                            <i class="ace-icon fa fa-clock-o bigger-110">
                            </i> 
                            <span class="time">
                              <?php echo $cmt->at; ?>
                            </span>
                            <?php } elseif($type=="change" && $ato==$name) { ?>
                            <?php echo $cmt->publisher_name; ?> Changed Task 
                            <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                              <?php echo $cmt->task_id; ?>
                            </a> To
                            <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                            <br>
                            <i class="ace-icon fa fa-clock-o bigger-110">
                            </i> 
                            <span class="time"> 
                              <?php echo $cmt->at; ?>
                            </span>
                            <?php } elseif($type=="task" && $ato==$name) { ?>
                            <?php echo $cmt->publisher_name; ?> Assigned Task 
                            <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                              <?php echo $cmt->task_id; ?>
                            </a> To
                            <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                            <br>
                            <i class="ace-icon fa fa-clock-o bigger-110">
                            </i> 
                            <span class="time"> 
                              <?php echo $cmt->at; ?>
                            </span>
                            <?php } ?>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <!-- Notifications for Admin, Manager -->
                    <?php if ($m>10) break; } } else { foreach ($ca->result() as $a => $cmt) { ?>
                    <tr class="cmt">
                      <td>
                        <div class="row">
                          <?php $type=$cmt->type; if($type=="comment") { ?>
                          <div class="col-md-1">
                            <i class="fa fa-commenting">
                            </i>
                          </div>
                          <?php } elseif($type=="resolved") { ?>
                          <div class="col-md-1">
                            <span class="glyphicon resolve glyphicon-ok"> 
                              </div>
                            <?php } elseif($type=="closed") { ?>
                            <div class="col-md-1">
                              <i class="fa fa-power-off" aria-hidden="true">
                              </i> 
                            </div>
                            <?php } elseif($type=="change") { ?>
                            <div class="col-md-1">
                              <i class="fa fa-exchange" aria-hidden="true">
                              </i> 
                            </div>
                            <?php } else { ?>
                            <div class="col-md-1">
                              <span class="glyphicon glyphicon-plus-sign">
                                </i>
                            </div>
                            <?php } ?>
                            <div class="col-md-11">
                              <?php if($type=="comment"){ ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?>
                              Commented On Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time"> 
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="resolved") { ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                              Resolved The Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time"> 
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="closed") { ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You have"; } else { echo $by; } ?>
                              Closed The Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time"> 
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } elseif($type=="change") { ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?>
                              Changed Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>"> 
                                <?php echo $cmt->task_id; ?>
                              </a> To
                              <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time"> 
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } else { ?>
                              <?php $by=$cmt->publisher_name; if($by==$name) { echo "You Were"; } else { echo $by; } ?>
                              Assigned Task 
                              <a href="task_view?id=<?php echo $cmt->task_id; ?>">
                                <?php echo $cmt->task_id; ?>
                              </a> To
                              <?php $to=$cmt->assigned_to; if($to==$name) { echo "You"; } else { echo $to; } ?>
                              <br>
                              <i class="ace-icon fa fa-clock-o bigger-110">
                              </i> 
                              <span class="time"> 
                                <?php echo $cmt->at; ?>
                              </span>
                              <?php } ?>
                            </div>
                          </div>
                          </td>
                    </tr>
                    <?php if ($a>10) break; } } ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Viewing All Employees and their Details. No permission for view this for Employees -->
        <?php if($role!="employee") { ?>
        <div class="row">
          <div class="col-md-12">
            <div class="panel-register panel-primary">
              <div class="panel-heading">
              	<h3 class="panel-title">Employees</h3>
                
              </div>
              <div class="panle-body text-center">
                <div class="table-responsive">
                  <table class="table table-bordered">
                    <tr>
                      <th class="text-center">Employee_ID
                      </th>
                      <th class="text-center">Name
                      </th>
                      <th class="text-center">Username
                      </th>
                      <th class="text-center">Email
                      </th>
                      <th class="text-center">Role
                      </th>
                      <th class="text-center">Mobile
                      </th>
                    </tr>
                    <?php foreach ($h->result() as $row) { ?>
                    <tr>
                      <td>
                        <?php echo $row->user_id; ?>
                      </td>
                      <td>
                        <?php echo $row->name; ?>
                      </td>
                      <td>
                        <?php echo $row->user_name; ?>
                      </td>
                      <td>
                        <?php echo $row->user_email; ?>
                      </td>
                      <td>
                        <?php echo $row->user_role; ?>
                      </td>
                      <td>
                        <?php echo $row->user_mobile; ?>
                      </td>
                    </tr>
                    <?php } ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php } ?>
        </div>
      </div>
    </div>
  </aside>
</article>      
<!-- Calling Footer From Views/Templates Path -->
<?php $this->load->view('templates/footer'); ?>
</body>
</html>
