<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
$role=$this->session->userdata('user_role');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - Task Assign System
    </title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8">
    </script>
    <script type="text/javascript" src ="<?php echo base_url(); ?>js/validator.js">
    </script>
  </head>  
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-2">
            </div>
            <!-- User Profile View Section -->
            <div class="col-md-8">
              <div class="panel-register-profile info panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">
                    <i class="fa fa-user" aria-hidden="true">
                    </i> Profile
                  </h3>
                </div>
                <div class="panel-body">
                  <?php
$error=$this->session->flashdata('error');
$success= $this->session->flashdata('success');
$password_error=$this->session->flashdata('password_error');
$password_success= $this->session->flashdata('password_success');
if($success){
?>
                  <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $success; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  <?php }
if($password_success){
?>
                  <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $password_success; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  <?php }
if($password_error){
?>
                  <div class="alert alert-dismissible alert-danger" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $password_error; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  <?php }
if($error){ ?>
                  <div class="alert alert-dismissible alert-danger" id="myAlert">
                    <span class="glyphicon glyphicon-remove">
                    </span> 
                    <?php echo $error; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  <?php } ?>
                  <?php foreach($u->result() as $usr) { ?> 
                  <div class="well well-sm">
                    <i class="fa fa-user" aria-hidden="true">
                    </i> 
                    <b>Profile
                    </b>
                  </div>
                  <form role="form" id="identicalForm" method="post" action="update_profile" enctype="multipart/form-data" autocomplete="off" >
                    <fieldset>
                      <div class="row">
                        <div class="col-md-3">Name
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" value="<?php echo $usr->name; ?>" name="name" type="text" required="required" readonly>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-3">Username
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" value="<?php echo $usr->user_name; ?>" name="usr_name" type="text" required="required">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-3">Email
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" value="<?php echo $usr->user_email; ?>" name="email" type="email" required="required">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-3">Mobile
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" value="<?php echo $usr->user_mobile; ?>" name="mobile" type="number" required="required" value="">
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <input class="btn btn-warning center-block" name="update" type="submit" value="Update Profile">
                      </div>
                    </fieldset>
                  </form>
                  <div class="well well-sm">
                    <i class="fa fa-key" aria-hidden="true">
                    </i> 
                    <b>Password
                    </b>
                  </div>
                  <form role="form" data-toggle="validator" method="post" action="password" enctype="multipart/form-data" autocomplete="off" >
                    <fieldset>
                      <div class="row">
                        <div class="col-md-3">Old Password
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" name="old_password" 
                                   type="password" id="password" data-toggle="password" required="required" autocomplete="off" />
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-3">New Password
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" name="new_password" 
                                   type="password" id="inputPassword" data-toggle="password" required="required" autocomplete="off" />
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-3">Confirm New Password
                        </div>
                        <div class="col-md-9">
                          <div class="form-group">
                            <input class="form-control" name="confirm_password" type="password" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Password and Confirm Password are't match...." data-toggle="password" required="required" value="" />
                            <div class="help-block with-errors">
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <input class="btn btn-warning center-block" name="password" type="submit" value="Update Password">
                      </div>
                    </fieldset>
                  </form>
                  <?php } ?>
                </div>
                <div class="col-md-2">
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </article>      
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
</html>
