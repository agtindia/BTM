<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
  <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.4.js">
  </script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js">
  </script>
  <link rel="stylesheet" type="text/css" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  	<!-- Table Export Script -->

    <script>
      $(function(){
        $("#export").click(function(){
          $("#export_table").tableToCSV();
        });
      });      
    </script>

    <!-- Data Table JS Script -->

    <script type="text/javascript">
      $(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#example thead tr td').each( function (i) {
        var title = $('#example thead tr th').eq( $(this).index() ).text();
        $(this).html( '<input type="text" class="search-box" placeholder="Search '+title+'" data-index="'+i+'" />' );
    } );
  
    // DataTable
    var table = $('#example').DataTable();
 
    // Filter event handler
    $( table.table().container() ).on( 'keyup', ' #example thead tr td input', function () {
        table
            .column( $(this).data('index') )
            .search( this.value )
            .draw();
    } );
} );
    </script>

    <!-- Date Pick JS Script -->

    <script>
      $(document).ready(function(){
      $("#datepicker").datepicker({
          minDate: 0,
          numberOfMonths: 2,
          dateFormat: 'dd/mm/yy',
          onSelect: function(selected) {
          $("#datepicker1").datepicker("option","minDate", selected)
        }
      });
      $("#datepicker1").datepicker({
          minDate: 0,
          numberOfMonths: 2,
          dateFormat: 'dd/mm/yy',
          onSelect: function(selected) {
           $("#datepicker").datepicker("option","maxDate", selected)
        }
      }); 
      });
    </script>
  </head>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <!-- Storing User Role From Session Data In Role Variable -->
    <?php $role=$this->session->userdata('user_role'); $this->load->helper('form'); ?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <?php if($role!="employee") { ?>
          <div class="row">
            <div class="col-md-12">
              <div class="panel-register-profile info panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">All</h3>
                    <a href="#" id="export" class="view-all-btn" data-export="export">Export</a>
                </div>
                <div class="panel-body">
                  <div class="table-responsive">
                    <table id="example" class="table table-bordered"> 
                      <thead>
                        <tr>
                          <td>ID</td>
                          <td>Title</td>
                          <td>Category</td>
                          <td>At</td>
                          <td>By</td>
                          <td>To</td>
                          <td>Status</td>
                          <td>Start</td>
                          <td>Due</td>
                        </tr>                     
                        <tr>
                          <th class="text-center">ID</th>
                          <th class="text-center">Title</th>
                          <th class="text-center">Category</th>
                          <th class="text-center">At</th>
                          <th class="text-center">By</th>
                          <th class="text-center">To</th>
                          <th class="text-center">Status</th>
                          <th class="text-center">Start</th>
                          <th class="text-center">Due</th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php foreach ($a->result() as $task) { $status=$task->status; ?>
                      <tr>
                        <td><?php echo $task->id; ?></td>
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>                   
                          </a>
                        </td>
                        <td><?php echo $task->category; ?></td>
                        <td><?php echo $task->time; ?></td>
                        <td><?php echo $task->assigned_by; ?></td> 
                        <td><?php echo $task->assigned_to; ?></td>
                        <td>
                          <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                        </td>
                        <td><?php echo $task->start_date; ?></td>
                        <td><?php echo $task->due_date; ?></td>
                        <td>
                          <a href="update?id=<?php echo $task->id ?>">
                            <i class="fa fa-pencil pencil grey" data-toggle="tooltip" title="Edit"></i>
                          </a>
                        </td>
                        <td>                          
                          <a href="delete?id=<?php echo $task->id ?>">
                            <i class="fa fa-trash-o" data-toggle="tooltip" title="Delete" onclick="return confirm('Are You Sure Delete?')"></i>
                          </a>
                        </td>
                      </tr>                    
                      <?php } ?>                      
                      </tbody> 
                    </table>
                  </div>
                </div>
                <?php echo form_close(); ?>
              </div>
            </div>
          </div>
          <?php } else { ?>
          <h1>Permission Denied....
          </h1>
          <?php } ?>
        </div>
      </aside>
    </article>
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
</html>


