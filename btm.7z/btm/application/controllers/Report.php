<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* User Controller Class */

class Report extends CI_Controller {

/* Function for Construct Model */

public function __construct()
{
  parent::__construct();
  $this->load->model(array('user_model','comment_model'));
}

/* Function for Load (View) Login Form */

public function index()
{
	$this->load->helper('form');
	$this->load->view("report");
}

}

?>
