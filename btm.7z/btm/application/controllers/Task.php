<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* Task View Controller */

class Task extends CI_Controller{

	/* Load helper, library, model */

	function __construct()
	{
        parent::__construct();
        $this->load->helper(array('form','url'));
        $this->load->model(array('user_model','assign_model','task_model','comment_model'));
        $this->load->library('session');
	}

	/* Viewing Single Task */

	public function task_view()
	{
		$id=$this->input->get('id');
        $cmnt['cmt']=$this->comment_model->get_comment($id);
		$report['task']=$this->task_model->fetch_task($id);

        if($report['task'])
        {
		    $this->load->view('task_view', $report);
            $this->load->view('comments', $cmnt);
        }
        else
        {
            $this->load->view('task_deleted');
        }
	}

    /* View Notifications individual page */

    public function notifications()
    {
        $name=$this->session->userdata('name');
        $data['cm']=$this->comment_model->get($name);
        $data['ca']=$this->comment_model->get_all();
        $this->load->view('notifications', $data);
    }

	/* Viewing Update Page */

	public function update_view()
	{
		$id=$this->input->get('id');
		$report['update']=$this->task_model->fetch_task($id);
        $report['h']=$this->assign_model->fetchtable();
        $report['cat']=$this->assign_model->get_categories(); 
		$this->load->view('update_task',$report);
	}

	/* Update Task Function */

	public function update_task()
	{
		$id=$this->input->get('id');

        date_default_timezone_set('Asia/Calcutta');

        $to=$this->input->post('to');
        $at=$this->input->post('at');
        $assigned_to=$this->input->post('ato');

        // Mail configurations

            $name=$to;            
            $publisher_name=$this->session->userdata('name');
            $user['email']=$this->user_model->get_email($name);
            foreach($user['email']->result() as $email)
            {
                $mail=$email->user_email;
            }
            
            $email_current=$this->session->userdata('user_email');

        // End Mail Config...       

        if($to==$assigned_to)
        {
            $task_info = array(
                    'title' => $this->input->post('title'),
                    'description' => $this->input->post('description'),
                    'priority' => $this->input->post('priority'),
                    'category' => $this->input->post('category'),
                    'status' => $this->input->post('status'),
                    'start_date' => $this->input->post('start'),
                    'due_date' => $this->input->post('due'),
                    'end_date' => $this->input->post('end'), 
                    'working_hours' => $this->input->post('hours'),
                    'assigned_to' => $to
                    );

            $update_task=$this->task_model->update_task($id,$task_info);

            $config = array('mailtype'=>'html');
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");    
            $this->email->from('taskmanager@agtindia.com', $publisher_name.' (Task Management System)');
            $this->email->to($mail);
            $this->email->subject('New Task'); 
            $this->email->message($publisher_name.' Updated The Task... Click <a href=http://btmagt.agtindia.co.in/user>Here</a> To View');
            $this->email->send();
        }
        else
        {
            $task_info = array(
                    'title' => $this->input->post('title'),
                    'description' => $this->input->post('description'),
                    'priority' => $this->input->post('priority'),
                    'status' => "New",
                    'start_date' => $this->input->post('start'),
                    'due_date' => $this->input->post('due'),
                    'end_date' => $this->input->post('end'),
                    'working_hours' => $this->input->post('hours'),
                    'assigned_to' => $to
                    );

            $publisher_id=$this->session->userdata('user_id');
            $publisher_name=$this->session->userdata('name');
            $publisher_role=$this->session->userdata('user_role');

            // Send Mail To User

            $config = array('mailtype'=>'html');
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");    
            $this->email->from('taskmanager@agtindia.com', $publisher_name.' (Task Management System)');
            $this->email->to($mail);
            $this->email->subject('New Task'); 
            $this->email->message($publisher_name.' Assigned A Task To You... Click <a href=http://btmagt.agtindia.co.in/user>Here</a> To View');
            $this->email->send();

            $type="change";

            $comment=array(
                'type'=>$type,
                'comment'=>$type,
                'publisher_id'=>$publisher_id,
                'publisher_name'=>$publisher_name,
                'publisher_role'=>$publisher_role,
                'task_id'=>$id,
                'assigned_to'=>$to,
                'current'=>$assigned_to,
                'at'=>date('d-m-Y H:i:s')
            );

            $insert=$this->comment_model->insert($comment);
            $update_task=$this->task_model->update_task($id,$task_info);
        }

		$status=$this->input->post('status');

       	$report['update']=$this->task_model->fetch_task($id);
        $report['h']=$this->assign_model->fetchtable();
        /* Update Task as Ongoing if status is Ongoing */

        if($update_task && $status=="Ongoing")
        {
            $info=array('start'=>date('d-m-Y H:i'));

            $this->task_model->begin($id,$info);
            $this->session->set_tempdata('success','Task Updated Successfully...',3);
            redirect('update?id='.$id);
        }

        /* Update Task as Resolved if status is Resolved */

        elseif($update_task && $status=="Resolved")
        {
			$publisher_id=$this->session->userdata('user_id');
			$publisher_name=$this->session->userdata('name');
			$publisher_role=$this->session->userdata('user_role');

			$type="resolved";
			
			date_default_timezone_set('Asia/Calcutta');

      		$comment=array(
      			'type'=>$type,
      			'comment'=>$type,
      			'publisher_id'=>$publisher_id,
      			'publisher_name'=>$publisher_name,
      			'publisher_role'=>$publisher_role,
      			'task_id'=>$id,
      			'assigned_to'=>$to,
                'current'=>$to,
      			'at'=>date('d-m-Y H:i:s')
        	);
			$this->comment_model->insert($comment);

            $info=array('end'=>date('d-m-Y H:i'));
            $this->task_model->end($id,$info);

            $this->session->set_tempdata('success','Task Updated Successfully...',3);
            redirect('update?id='.$id);
        }

        /* Update Task as Closed if status is Closed */

        elseif($update_task && $status=="Closed")
        {
            $publisher_id=$this->session->userdata('user_id');
            $publisher_name=$this->session->userdata('name');
            $publisher_role=$this->session->userdata('user_role');

            $type="closed";
            
            date_default_timezone_set('Asia/Calcutta');

            $comment=array(
                'type'=>$type,
                'comment'=>$type,
                'publisher_id'=>$publisher_id,
                'publisher_name'=>$publisher_name,
                'publisher_role'=>$publisher_role,
                'task_id'=>$id,
                'assigned_to'=>$to,
                'current'=>$to,
                'at'=>date('d-m-Y H:i:s')
            );
            $this->comment_model->insert($comment);
            $this->session->set_tempdata('success','Task Updated Successfully...',3);
            redirect('update?id='.$id);
        }

        /* Update Task */

		elseif($update_task)
		{
            $this->session->set_tempdata('success','Task Updated Successfully...',3);
            redirect('update?id='.$id);
		}

        /* If Update Failes */

        else
        {
            $this->session->set_tempdata('error','Task Update Failed..',3);
            redirect('update?id='.$id);
        }
	}

    /* Get Tasks assigned to current User */

    public function to()
    {
        $data['t']=$this->task_model->to();  
        $this->load->view('task_to', $data);
    }

    /* Get All Tasks From Database  */

    public function all()
    {
        $data['h']=$this->assign_model->fetchtable();        
        $data['cat']=$this->assign_model->get_categories();
        $data['a']=$this->task_model->all(); 
        $this->load->view('task_all', $data);
    }

    /* Get All Tasks Assigned By Current User  */

    public function me()
    {
        $data['b']=$this->task_model->me();  
        $this->load->view('task_by', $data);
    }

    /* Get All Tasks those are Resolved */

    public function resolved()
    { 
        $data['r']=$this->task_model->resolved();
        $this->load->view('task_resolved', $data);
    }

	/* Search Function for major roles */

    public function search()
    { 
		$key=$this->input->get('q');
        $data['rows'] = $this->task_model->search_task($key);			
		$this->load->view('search_results', $data);
    }
	
	/* Search Function For Employess */

    public function search_emp()
    { 
		$name=$this->session->userdata('name');
		$key=$this->input->get('q');
        $data['rows'] = $this->task_model->search_emp($key,$name);			
		$this->load->view('search_results', $data);
    }
    
}

?>