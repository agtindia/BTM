<?php 

defined('BASEPATH') OR exit('No direct script access allowed');  

$user_id=$this->session->userdata('user_id');
$role=$this->session->userdata('user_role');

if(!$user_id)
{
  redirect('login');
}

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Employee</title>

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/css/task.css">

<script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.js"></script>

<script type="text/javascript" src ="<?php echo base_url(); ?>js/validator.js"></script>

<script>
$(document).ready(function(){
    $(".close").click(function(){
        $("#myAlert").alert("close");
    });
});
</script>

</head>

<body>

<!-- Calling Header From Views/Templates Path -->

<?php $this->load->view('templates/header'); ?>

<article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <br>

    <div class="row">

    <div class="col-md-8">


          <!-- Viewing All Employees and their Details. No permission for view this for Employees -->
          <?php if($role!="employee") { ?>
          <div class="row">
            <div class="col-md-12">
              <div class="panel-register panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">Employees
                  </h3>
                </div>
                <div class="panle-body text-center">
                  <div class="table-responsive">
                    <table class="table table-bordered">
                      <tr>
                        <th class="text-center">Employee_ID
                        </th>
                        <th class="text-center">Name
                        </th>
                        <th class="text-center">Username
                        </th>
                        <th class="text-center">Email
                        </th>
                        <th class="text-center">Role
                        </th>
                        <th class="text-center">Mobile
                        </th>
                        <?php if($role!="reporter") { ?>
                          <th class="text-center">
                          </th>                        
                        <?php } ?>
                      </tr>
                      <?php foreach ($h->result() as $row) { ?>
                      <tr>
                        <td>
                          <?php echo $row->user_id; ?>
                        </td>
                        <td>
                          <?php echo $row->name; ?>
                        </td>
                        <td>
                          <?php echo $row->user_name; ?>
                        </td>
                        <td>
                          <?php echo $row->user_email; ?>
                        </td>
                        <td>
                          <?php echo $row->user_role; ?>
                        </td>
                        <td>
                          <?php echo $row->user_mobile; ?>
                        </td>                        
                        <?php if($role!="reporter") { ?>
                        <td>
                          <a href="profile_user?id=<?php echo $row->user_id ?>">
                          <button type="button" data-toggle="tooltip" title="Edit" name="update"> 
                                <i class="fa fa-pencil pencil grey"></i>
                          </button>
                          </a>
                        </td>
                        <?php } ?>
                      </tr>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php } ?>

    </div>

    <?php if($role=='admin' || $role=='manager') { ?>

    <div class="col-md-4">

    <div class="panel-register-profile panel-primary">

        <div class="panel-heading">
            <h3 class="panel-title"> <i class="fa fa-plus" aria-hidden="true"></i> Add Employee</h3>
        </div>

        <div class="panel-body">

            <?php
                $error_msg=$this->session->flashdata('error_msg');
                $success_msg= $this->session->flashdata('success_msg');

            if($success_msg){?>

                <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok"></span> <?php echo $success_msg; ?>
                    <a href="#" class="close">&times;</a>
                </div>

            <?php } if($error_msg){ ?>

                <div class="alert alert-dismissible alert-danger" id="myAlert">
                    <span class="glyphicon glyphicon-remove"></span> <?php echo $error_msg; ?>
                    <a href="#" class="close">&times;</a>
                </div>

            <?php } ?>

            <form role="form" method="post" data-toggle="validator" action="user/register_user" autocomplete="off" >

                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="Name" name="name" type="text" required="required">
                        </div>

                        <div class="form-group">
                            <input class="form-control" placeholder="Username" name="user_name" type="text" required="required">
                        </div>

                        <div class="form-group">
                            <input class="form-control" placeholder="E-mail" name="user_email" type="email" required="required">
                        </div>

                        <div class="form-group">
                            <input class="form-control" placeholder="Password" id="inputPassword" data-toggle="password" name="user_password" type="password" id="password" data-toggle="password" required="required" autocomplete="off">
                        </div>

                        <div class="form-group">
                            <input class="form-control" placeholder="Confirm Password" name="confirm_password" type="password" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Password and Confirm Password are't match...." data-toggle="password" required="required" value="">
                            <div class="help-block with-errors"></div>
                        </div>

                        <div class="form-group">
                            <select class="form-control" name="user_role" required="required" value="">
                                <option value="role" disabled="disabled" selected="selected">Select Role</option>
                                <option value="admin">Admin</option>
                                <option value="manager">Manager</option>
                                <option value="employee">Employee</option>
                                <option value="reporter">Reporter</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <input class="form-control" placeholder="Mobile No" name="user_mobile" type="number" required="required" value="">
                        </div>

                        <input class="btn btn-primary btn-block" type="submit" value="+ Add" required="required" name="register">

                    </fieldset>
                </form>
        </div>

    </div>

    </div>

    <?php } else { echo "<h1>Permission Denied..</h1>"; } ?>

    </div>

    <br>
        </div>
      </aside>
</article>      

<!-- Calling Header From Views/Templates Path -->

<?php $this->load->view('templates/footer'); ?>

</body>

</html>
