<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  
$user_id=$this->session->userdata('user_id');
$role=$this->session->userdata('user_role');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/css/task.css/bootstap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/css/task.css">
    <title>Task Deleted - Task Assign System</title>
  </head>  
    <?php $this->load->view('templates/header'); ?>
  <body>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <h1>The Task has been deleted... Contact Admin
          </h1>
          <h4>You will be redirect in a moment.........
          </h4>
          <?php header("Refresh:4;url=".base_url()."user"); ?>
        </div>
      </aside>
    </article>      
  </body>
</html>
