<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* Assign Controller */

class Assign extends CI_Controller{

	/* Load helper, library, model */

	function __construct()
	{
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model(array('assign_model','comment_model','user_model','task_model'));
        $this->load->library('session');
        $this->load->library('email');
	}

	/* View Task Assign Form With the All User Names */

	public function index()
	{
		$data['h']=$this->assign_model->fetchtable(); 
		$data['c']=$this->assign_model->get_categories();  
	    $this->load->view('assign_form', $data);
		
	}

	public function report()
	{
		$this->load->view('issue');
	}

	/* Task Assign Function */

	public function task_assign()
	{

		$name=$this->session->userdata('name');

		date_default_timezone_set('Asia/Calcutta');
		
		$config = array(
			'upload_path' => "./uploads/",
			'allowed_types' => "gif|jpg|jpeg|png|doc|docx|csv|xls|xlsx|pdf|txt|css|html|js|php|rar|zip",
			'overwrite' => FALSE,
			'max_size' => "200000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
			'max_height' => "768",
			'max_width' => "1024"
		);
		/* Loading CI Upload Library */

		$this->load->library('upload', $config);

		/* If The Upload File is Satisfy for Above Conditions */

		$file =$this->input->post('user_file');

		/* If all is correct */

		if($this->upload->do_upload('userfile') || !(file_exists($file)))
		{

		$data=array('upload_data' => $this->upload->data());
      	$task=array(
      			'title'=>$this->input->post('task_title'),
      			'description'=>$this->input->post('task_description'),
      			'priority'=>$this->input->post('task_priority'),
      			'category'=>$this->input->post('category'),
      			'status'=>'New',
      			'start_date'=>$this->input->post('task_start'),
      			'due_date'=>$this->input->post('task_due'),
      			'assigned_to'=>$this->input->post('task_to'),
      			'assigned_by'=> $name,
      			'time'=> date('d.m.Y H:i:s'),
      			'task_file' => $this->upload->data('file_name'),
      			'start' => '-',
      			'end'=>'-'
        	);
        print_r($task);
		$assign=$this->assign_model->assign_task($task);

		if($assign)
		{			

  			$last['row']=$this->assign_model->get_last_row();
			foreach($last['row']->result() as $issue)
            {
                $id=$issue->id;
                $at=$issue->time;
			}
			$publisher_id=$this->session->userdata('user_id');
			$publisher_name=$this->session->userdata('name');
			$publisher_role=$this->session->userdata('user_role');

			$type="task";

      		$comment=array(
      			'type'=>$type,
      			'comment'=>$type,
      			'publisher_id'=>$publisher_id,
      			'publisher_name'=>$publisher_name,
      			'publisher_role'=>$publisher_role,
      			'task_id'=>$id,
      			'assigned_to'=>$this->input->post('task_to'),
      			'current'=>$this->input->post('task_to'),
      			'at'=>$at
        	);

			$insert=$this->comment_model->insert($comment);

			$name=$this->input->post('task_to');
			$user['email']=$this->user_model->get_email($name);
			foreach($user['email']->result() as $email)
            {
                $mail=$email->user_email;
			}

			$email_current=$this->session->userdata('user_email');

			// Send Mail To User

			$config['mailtype'] = 'html';
			$config['protocol'] = 'sendmail';
			$config['charset'] = 'iso-8859-1';
			$config['wordwrap'] = TRUE;

			$this->email->initialize($config);
         	$this->email->set_newline("\r\n");    
         	$this->email->from('tamilselvan.agt@gmail.com', $publisher_name.' (Task Management System)'
         	);
         	$this->email->to('tamilselvan.agt@gmail.com');
         	$this->email->subject('New Task'); 
         	$this->email->message($publisher_name.'Assigned A Task To You ...
             <table>
				<tr>
					<td>Title</td>
					<td>'.$task['title'].'</td>
				</tr>
				<tr>
					<td>Description</td>
					<td>'.$task['description'].'</td>
				</tr>
				<tr>
					<td>Category</td>
					<td>'.$task['category'].'</td>
				</tr>
				<tr>
					<td>Priority</td>
					<td>'.$task['priority'].'</td>
				</tr>
				<tr>
					<td>Due Date</td>
					<td>'.$task['due_date'].'</td>
				</tr>
			</table>
         	 Click <a href=http://btmagt.agtindia.co.in/user>Here</a> To View');
         	$this->email->send();

		  	$this->session->set_flashdata('success_msg','Task Assigned to '.$task['assigned_to'].' Successfully...');
  		  	redirect('assign');
		}

		else
		{	
			$this->session->set_flashdata('error_msg', 'Could not Assign task');
  			redirect('assign');			  	
		}

		}

		/* If invalid file type it will display errors. */

		if(!$this->upload->do_upload('userfile'))
		{
			$error = array('error' => $this->upload->display_errors());
			$this->load->view('file_error', $error);
		}

	}

	public function mail() { 

		$config['mailtype'] = 'html';

		$this->email->initialize($config);
        $this->email->to('tamilselvan.agt@gmail.com');
        $this->email->subject('New Task');    
        $this->email->from('tamilselvan.agt@gmail.com','(Task Management System)');

		$this->email->send();
      }
}

?>