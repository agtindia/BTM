<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8">
    </script>  
    <script type="text/javascript" src ="<?php echo base_url(); ?>js/jquery.tabletoCSV.js">
    </script>
    <script>
      $(function(){
        $("#export").click(function(){
          $("#export_table").tableToCSV();
        }
                          );
      }
       );
    </script>
  </head>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <!-- Storing User Role From Session Data In Role Variable -->
    <?php $role=$this->session->userdata('user_role'); ?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <!-- View All Resolved Tasks -->
          <div class="row">
            <div class="col-md-12">
              <div class="panel-register-profile info panel-primary">
                <div class="panel-heading">
                  <div class="row">
                    <div class="col-md-10">   
                      <h3 class="panel-title">
                        <i class="ace-icon fa fa-list-alt">
                        </i> Resolved
                      </h3>
                    </div>
                    <div class="col-md-2">
                      <button class="btn btn-warning btn-sm" id="export" data-export="export">Export
                      </button>
                    </div>
                  </div>
                </div>
                <div class="body">
                  <div class="table-responsive">
                    <table id="export_table" class="table table-bordered text-center">
                      <?php $role=$this->session->userdata('user_role'); ?>
                      <?php $name=$this->session->userdata('name'); ?>
                      <tr>
                        <th class="text-center">ID
                        </th>
                        <th class="text-center">Title
                        </th>
                        <th class="text-center">Created At
                        </th>
                        <th class="text-center">Start Date
                        </th>
                        <th class="text-center">Due Date
                        </th>
                        <th class="text-center">End Date
                        </th>
                      </tr>
                      <?php foreach ($r->result() as $task) { ?>
                      <tr class="link bg-success">
                        <?php if($role=="employee") { if($task->assigned_to==$name) { ?>
                        <td>
                          <?php echo $task->id; ?>
                        </td>                    
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>
                        <td>
                          <?php echo $task->time; ?>
                        </td> 
                        <td>
                          <?php echo $task->start_date; ?>
                        </td>  
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>    
                        <td>
                          <?php echo $task->end_date; ?>
                        </td>
                        <?php } } else { ?>
                        <td>
                          <?php echo $task->id; ?>
                        </td> 
                        <td>
                          <a href="task_view?id=<?php echo $task->id ?>">
                            <?php echo $task->title; ?>
                          </a>
                        </td>
                        <td>
                          <?php echo $task->time; ?>
                        </td>
                        <td>
                          <?php echo $task->start_date; ?>
                        </td>  
                        <td>
                          <?php echo $task->due_date; ?>
                        </td>    
                        <td>
                          <?php echo $task->end_date; ?>
                        </td>
                      </tr>
                      <?php } } ?>
                    </table>
                  </div>
                  <?php echo form_close(); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </article>
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
</html>
