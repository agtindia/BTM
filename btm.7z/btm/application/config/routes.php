<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/

/* This is the URL of all pages you can assign own URL here */

$route['default_controller'] = 'user';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['login'] = 'user';
$route['user'] = 'user/user_profile';
$route['admin'] = 'user/user_profile';
$route['register'] = 'user/register_view';
$route['logout'] = 'user/user_logout';
$route['assign'] = 'assign';
$route['delete'] = 'user/delete';
$route['profile'] = 'profile';
$route['categories'] = 'user/categories';
$route['update_profile'] = 'profile/update_profile';
$route['profile_user'] = 'profile/profile_user';
$route['update_user_profile'] = 'profile/update_user_profile';
$route['password'] = 'profile/update_password';
$route['user_password'] = 'profile/update_user_password';
$route['report'] = 'assign/report';
$route['task_view'] = 'task/task_view';
$route['update'] = 'task/update_view';
$route['update_task'] = 'task/update_task';
$route['comment'] = 'comment/insert_comment';
$route['to'] = 'task/to';
$route['by'] = 'task/me';
$route['all'] = 'task/all';
$route['resolved'] = 'task/resolved';
$route['notifications'] = 'task/notifications';
$route['forgot'] = 'user/forgot';
$route['search'] = 'task/search';
$route['search_task'] = 'task/search_emp';
$route['report'] = 'report';
$route['mail'] = 'assign/mail';


