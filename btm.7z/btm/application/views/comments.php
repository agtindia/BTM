
<!-- Comments View -->

<?php 

defined('BASEPATH') OR exit('No direct script access allowed');  

$user_id=$this->session->userdata('user_id');

$role=$this->session->userdata('user_role');

$name=$this->session->userdata('name');

if(!$user_id){

  redirect('login');
}

?>

    <!-- Viewing Comments -->

    <div class="panel-register info panel-primary">

     <div class="panel-heading">

        <h3 class="panel-title"><i class="fa fa-comments" aria-hidden="true"></i> Comments</h3>

     </div>

     <div class="panel-body">

        <?php foreach ($cmt->result() as $comment) { ?>

        <div class="well well-sm comment-box">

   		    <p>
   			    <i class="fa fa-user" aria-hidden="true"></i> : <b><?php echo $comment->publisher_name; ?></b>

   			    (<?php echo $comment->publisher_role; ?>), 

                <i class="fa fa-clock-o" aria-hidden="true"></i> : <i>

                <b><?php echo $comment->at; ?></b></i>
                
   		    </p><hr>
            
            <span class="comment"><?php echo $comment->comment; ?></span>

        </div>

        <?php } ?>

     </div>

    </div>

    <!-- Comment Box -->

    <div class="panel-register info panel-primary">

        <div class="panel-heading">

            <h3 class="panel-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Post A Comment</h3>

        </div>

   		<form role="form" method="post" action="comment" enctype="multipart/form-data" autocomplete="off" >

   			<input value="<?php foreach ($task->result() as $issue) { echo $issue->id; } ?>" name="task_id" type="hidden">

            <input value="<?php foreach ($task->result() as $issue) { echo $issue->assigned_to; } ?>" name="to" type="hidden">

        	<table class="table table-bordered table-responsive">
    	   		<tr>
            		<th>
                		<textarea class="form-control" cols="80" rows="7" name="comment"></textarea>
            		</th>
    	   		</tr>
    	   		<tr>
            		<th colspan="2">
                        <?php 

                        foreach ($task->result() as $issue) {

                            if($role=="employee") 

                                { 
                                    if($issue->assigned_to==$name) 

                                        { 
                        ?>

            			<input class="btn btn-primary" type="submit" value="Post Comment" name="post">

                        <?php } else { ?>

                        <input class="btn btn-primary" type="hidden" value="Post Comment" name="post">

                        <?php } } else { ?>

                        <input class="btn btn-primary" type="submit" value="Post Comment" name="post">

                        <?php } } ?>
            		</th>
    	   		</tr>
    		</table>

    	</form>

      </div>

    </div>

</div>

</div>
</aside>
</article>

<?php $this->load->view('templates/footer'); ?>

</body>

</html>
