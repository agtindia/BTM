<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
foreach($update->result() as $data) {
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Update Task - Task Assign System </title>  
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js">
    </script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Jquery Datepicker -->

    <script>
      $(document).ready(function(){
      $("#datepicker").datepicker({
          minDate: 0,
          numberOfMonths: 2,
          dateFormat: 'dd/mm/yy',
          onSelect: function(selected) {
          $("#datepicker1").datepicker("option","minDate", selected)
        }
      });
      $("#datepicker1").datepicker({
          minDate: 0,
          numberOfMonths: 2,
          dateFormat: 'dd/mm/yy',
          onSelect: function(selected) {
          $("#datepicker").datepicker("option","maxDate", selected)
        }
      });
      $("#datepicker2").datepicker({
          minDate: 0,
          numberOfMonths: 2,
          dateFormat: 'dd/mm/yy',
          onSelect: function(selected) {
          $("#datepicker1").datepicker("option","minDate", selected)
        }
      });
      });
    </script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
    </script>
    <script src="<?php echo base_url() ?>/application/asset/js/tinymce/tinymce.min.js">
    </script>
    <script type="text/javascript">
      tinymce.init({
        selector: "textarea",
        plugins: "link image"
      });
    </script>
  </head>

  <!-- Calling Header From Views/Templates Path -->
  <?php $this->load->view('templates/header'); ?>

  <body>

    <!-- Storing current user data -->
    <?php $role=$this->session->userdata('user_role'); ?>
    <?php $name=$this->session->userdata('name'); ?>
    <?php $by=$data->assigned_by; ?>
    <article>

      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <?php if($role=="employee") { if($data->assigned_to==$name) { ?>
          <div class="row">
            <div class="col-md-2">
            </div>
            <!-- Task Update Section -->
            <div class="col-md-8">
              <div class="panel-register-update panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">
                    <i class="fa fa-pencil-square-o" aria-hidden="true">
                    </i> Update Task
                  </h3>
                </div>
                <div class="panel-body">
                  <!-- Viewing Error or Success Message -->
                  <?php
                    $error=$this->session->tempdata('error');
                    $success= $this->session->tempdata('success');
                    if($success) {
                  ?>
                  <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $success; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  <script>swal("Done!", "<?php echo $success; ?>", "success");</script>
                  <?php } if($error) { ?>
                  <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $success; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  <?php } ?>
                  <!-- Task Update Form -->
                  <form role="form" method="post" action="update_task?id=<?php echo $data->id; ?>" enctype="multipart/form-data" autocomplete="off" >
                    <fieldset>

                      <div class="row">
                        <div class="col-md-2">Title
                        </div>
                        <div class="col-md-10">
                          <div class="form-group">
                            <input class="form-control" value="<?php echo $data->title; ?>" name="title" type="text" required="required" 
                                   <?php if($role=="employee"&&$by!=$name){ echo 'readonly'; } ?> >
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-md-2">Description
                        </div>
                        <div class="col-md-10">
                          <div class="form-group">
                            <textarea id="description" class="form-control" cols="80" rows="7" name="description" <?php if($role=="employee"&&$by!=$name){ echo 'readonly'; } ?>><?php echo $data->description; ?>
                            </textarea>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-md-2">Category</div>
                        <div class="col-md-10">
                          <div class="form-group">                            
                            <?php if($role=="employee"&&$by!=$name) { ?>
                              <input class="form-control" value="<?php echo $data->category; ?>" name="category" type="text" readonly />
                            <?php } else { ?> 
                            <select class="form-control" name="category" required>
                              <option value="<?php echo $data->category; ?>">
                                <?php echo $data->category; ?>
                              </option>
                              <?php foreach ($cat->result() as $cat) { ?>
                              <?php if($cat->category!=$data->category) { ?>
                              <option value="<?php echo $cat->category; ?>">
                                <?php echo $cat->category; ?>                                       
                              </option>
                              <?php } } } ?>
                            </select>
                          </div>
                        </div>
                      </div>

                    <div class="row">
                      <div class="col-md-2">Priority
                      </div>
                      <div class="col-md-10">
                        <div class="form-group">
                          <select class="form-control" name="priority" required 
                                  <?php if($role=="employee"&&$by!=$name){ echo 'readonly'; }?> >
                          <?php $priority=$data->priority; if($role=="employee") {  ?>
                          <option value="<?php echo $data->priority; ?>" readonly> 
                            <?php echo $data->priority; ?>
                          </option>
                          <?php } else { ?>
                          <option value="Low" 
                                  <?php if($priority=="Low"){ echo 'selected="selected"'; } ?> >Low
                          </option>
                        <option value="Medium" 
                                <?php if($priority=="Medium"){ echo 'selected="selected"'; } ?> >Medium
                        </option>
                      <option value="High" 
                              <?php if($priority=="High"){ echo 'selected="selected"'; } ?> >High
                      </option>
                    <?php } ?>
                    </select>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-2">Start Date
              </div>
              <div class="col-md-10">
                <div class="form-group">
                  <input class="form-control" value="<?php echo $data->start_date; ?>" name="start"
                  id="datepicker" type="text" required="required" autocomplete="off">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-2">Due Date
              </div>
              <div class="col-md-10">
                <div class="form-group">
                  <input class="form-control" id="datepicker1" value="<?php echo $data->due_date; ?>" name="due"  type="text" required="required" autocomplete="off">
                </div>
              </div>
            </div>

            <!-- Hidden Inputs -->

            <input value="<?php echo $data->assigned_to; ?>" name="ato" type="hidden">
            <input value="<?php echo $data->time; ?>" name="at" type="hidden">

            <!-- End Hidden Inputs -->

            <div class="row">
              <div class="col-md-2">Assigned To
              </div>
              <div class="col-md-10">
                <div class="form-group">
                  <?php if($role=="employee") { ?>
                  <input class="form-control" value="<?php echo $data->assigned_to; ?>" name="to" type="text" readonly />
                  <?php } else { ?>
                  <select class="form-control" name="to" required 
                          <?php 
                  if($role=="employee"){ echo 'readonly'; }?> >
                  <option value="<?php echo $data->assigned_to; ?>">
                    <?php echo $data->assigned_to; ?>
                  </option>
                  <?php foreach ($h->result() as $row) { ?>
                  <?php if($row->name!=$data->assigned_to) { ?>
                  <option value="<?php echo $row->name; ?>">
                    <?php echo $row->name; ?>                                       
                  </option>
                  <?php } } } ?>
                  </select>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2">End Date
            </div>
            <div class="col-md-10">
              <div class="form-group">
                <input class="form-control" value="<?php echo $data->end_date; ?>" id="datepicker2" name="end"  type="text" autocomplete="off">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2">Total Hours Taken</div>
            <div class="col-md-10">
              <div class="form-group">
                <input class="form-control" placeholder="Ex. 2 Hours 20 Minutes" value="<?php echo $data->working_hours; ?>" name="hours"  type="text" autocomplete="off">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2">Status
            </div>
            <div class="col-md-10">
              <div class="form-group">
                <select class="form-control" name="status" required >
                  <?php $status=$data->status; ?>
                  <?php if($status=="Closed" && $role=="employee"&&$by!=$name) { ?>
                  <option value="Closed" readonly>Closed
                  </option>
                  <?php } else { ?>
                  <option value="New" 
                          <?php if($status=="New"){ echo 'selected="selected"'; } ?> >New
                  </option>
                <option value="Ongoing" 
                        <?php if($status=="Ongoing"){ echo 'selected="selected"'; } ?> >Ongoing
                </option>
              <option value="Resolved" 
                      <?php if($status=="Resolved"){ echo 'selected="selected"'; } ?> >Resolved
              </option>
            <?php if($role!="employee") { ?>
            <option value="Closed" 
                    <?php if($status=="Closed"){ echo 'selected="selected"'; } ?> >Closed
            </option>
          <?php } } ?>
          </select>
        </div>
      </div>
    </div>
  <input class="btn btn-primary btn-block" type="submit" value="Update Task"
         name="update">
  </fieldset>
</form>
</div>
</div>
</div>
<div class="col-md-2">
</div>
</div>
<?php } else { echo "<h1>Permission Denied....</h1>"; } } else { ?>

          <div class="row">
            <div class="col-md-2">
            </div>
            <!-- Task Update Section -->
            <div class="col-md-8">
              <div class="panel-register-update panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">
                    <i class="fa fa-pencil-square-o" aria-hidden="true">
                    </i> Update Task
                  </h3>
                </div>
                <div class="panel-body">
                  <!-- Viewing Error or Success Message -->
                  <?php
                      $error=$this->session->tempdata('error');
                      $success= $this->session->tempdata('success');
                      if($success){ ?>
                  <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $success; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>

                  <?php } if($error){ ?>

                  <div class="alert alert-dismissible alert-success" id="myAlert">
                    <span class="glyphicon glyphicon-ok">
                    </span> 
                    <?php echo $success; ?>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×
                    </a>
                  </div>
                  
                  <?php } ?>
                  <!-- Task Update Form -->
                  <form role="form" method="post" action="update_task?id=<?php echo $data->id; ?>" enctype="multipart/form-data" autocomplete="off" >
                    <fieldset>

                      <div class="row">
                        <div class="col-md-2">Title
                        </div>
                        <div class="col-md-10">
                          <div class="form-group">
                            <input class="form-control" value="<?php echo $data->title; ?>" name="title" type="text" required="required" 
                                   <?php if($role=="employee"){ echo 'readonly'; } ?> >
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-md-2">Description
                        </div>
                        <div class="col-md-10">
                          <div class="form-group">
                            <textarea id="description" class="form-control" cols="80" rows="7" name="description" <?php if($role=="employee"){ echo 'readonly'; } ?>><?php echo $data->description; ?>
                            </textarea>
                          </div>
                        </div>
                      </div>


                      <div class="row">
                        <div class="col-md-2">Category</div>
                        <div class="col-md-10">
                          <div class="form-group">
                            <select class="form-control" name="category" required>
                              <option value="<?php echo $data->category; ?>">
                                <?php echo $data->category; ?>
                              </option>
                              <?php foreach ($cat->result() as $cat) { ?>
                              <?php if($cat->category!=$data->category) { ?>
                              <option value="<?php echo $cat->category; ?>">
                                <?php echo $cat->category; ?>                                       
                              </option>
                              <?php } } ?>
                            </select>
                          </div>
                        </div>
                      </div>

                    <div class="row">
                      <div class="col-md-2">Priority
                      </div>
                      <div class="col-md-10">
                        <div class="form-group">
                          <select class="form-control" name="priority" required 
                                  <?php if($role=="employee"){ echo 'readonly'; }?> >
                          <?php $priority=$data->priority; if($role=="employee") {  ?>
                          <option value="<?php echo $data->priority; ?>" readonly> 
                            <?php echo $data->priority; ?>
                          </option>
                          <?php } else { ?>
                          <option value="Low" 
                                  <?php if($priority=="Low"){ echo 'selected="selected"'; } ?> >Low
                          </option>
                        <option value="Medium" 
                                <?php if($priority=="Medium"){ echo 'selected="selected"'; } ?> >Medium
                        </option>
                      <option value="High" 
                              <?php if($priority=="High"){ echo 'selected="selected"'; } ?> >High
                      </option>
                    <?php } ?>
                    </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-2">Start Date
              </div>
              <div class="col-md-10">
                <div class="form-group">
                  <input class="form-control" value="<?php echo $data->start_date; ?>" name="start"
                  <?php if($role!="employee"){ echo 'id="datepicker"'; } ?> type="text" required="required" autocomplete="off" <?php if($role=="employee"){ echo 'readonly'; } ?>>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-2">Due Date
              </div>
              <div class="col-md-10">
                <div class="form-group">
                  <input class="form-control" <?php if($role!="employee"){ echo 'id="datepicker1"'; } ?> value="<?php echo $data->due_date; ?>" name="due"  type="text" required="required" autocomplete="off" <?php if($role=="employee"){ echo 'readonly'; } ?>>
                </div>
              </div>
            </div>

            <!-- Hidden Inputs -->

            <input value="<?php echo $data->assigned_to; ?>" name="ato" type="hidden">
            <input value="<?php echo $data->time; ?>" name="at" type="hidden">

            <!-- End Hidden Inputs -->

            <div class="row">
              <div class="col-md-2">Assigned To
              </div>
              <div class="col-md-10">
                <div class="form-group">
                  <?php if($role=="employee") { ?>
                  <input class="form-control" value="<?php echo $data->assigned_to; ?>" name="to" type="text" readonly />
                  <?php } else { ?>
                  <select class="form-control" name="to" required 
                          <?php 
                  if($role=="employee"){ echo 'readonly'; }?> >
                  <option value="<?php echo $data->assigned_to; ?>">
                    <?php echo $data->assigned_to; ?>
                  </option>
                  <?php foreach ($h->result() as $row) { ?>
                  <?php if($row->name!=$data->assigned_to) { ?>
                  <option value="<?php echo $row->name; ?>">
                    <?php echo $row->name; ?>                                       
                  </option>
                  <?php } } } ?>
                  </select>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2">End Date
            </div>
            <div class="col-md-10">
              <div class="form-group">
                <input class="form-control" value="<?php echo $data->end_date; ?>" id="datepicker2" name="end"  type="text" autocomplete="off">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2">Total Hours Taken</div>
            <div class="col-md-8">
              <div class="form-group">
                <input class="form-control" placeholder="Ex. 2 Hours 20 Minutes" value="<?php echo $data->working_hours; ?>" name="hours"  type="text" autocomplete="off">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-2">Status
            </div>
            <div class="col-md-10">
              <div class="form-group">
                <select class="form-control" name="status" required >
                  <?php $status=$data->status; ?>
                  <?php if($status=="Closed" && $role=="employee") { ?>
                  <option value="Closed" readonly>Closed
                  </option>
                  <?php } else { ?>
                  <option value="New" 
                          <?php if($status=="New"){ echo 'selected="selected"'; } ?> >New
                  </option>
                <option value="Ongoing" 
                        <?php if($status=="Ongoing"){ echo 'selected="selected"'; } ?> >Ongoing
                </option>
              <option value="Resolved" 
                      <?php if($status=="Resolved"){ echo 'selected="selected"'; } ?> >Resolved
              </option>
            <?php if($role!="employee") { ?>
            <option value="Closed" 
                    <?php if($status=="Closed"){ echo 'selected="selected"'; } ?> >Closed
            </option>
          <?php } } ?>
          </select>
        </div>
      </div>
    </div>
  <input class="btn btn-primary btn-block" type="submit" value="Update Task"
         name="update">
  </fieldset>
</form>
</div>
</div>
</div>
<div class="col-md-2">
</div>
</div>
<?php } } ?>
</div>
</aside>
</article>
<!-- Calling Footer From Views/Templates Path -->
<?php $this->load->view('templates/footer'); ?>
</body>
</html>
