<?php

defined('BASEPATH') OR exit('No direct script access allowed');  

/* Assign Model Class */


class Profile_model extends CI_model{

    /* Loading Parent Construct */

    function __construct()  
    {  
      parent::__construct();
    }

    /* Get User Data From User Table */

    public function fetchuser($id)
    {    
      $this->db->select('*');
      $this->db->from('user');
      $this->db->where('user_id',$id);

      if($query=$this->db->get())
      {
        return $query;
      }
      
      else
      {
        return false;
      }

    }

    /* Getting Current User Old Password  */

    public function old_password()
    {

      $id=$this->session->userdata('user_id');

      $this->db->select('user_password');
      $this->db->where('user_id',$id);
      return $this->db->get('user');

    }

    /* Update User Profile  */

    public function update_profile($id,$user_info)
    {

      $this->db->where('user_id', $id);
      $query=$this->db->update('user', $user_info);

      if($query)
      {
        return true;
      }
      else
      {
        return false;
      }

    }

    /* Update User Password  */

    public function update_password($id,$user_password)
    {

      $this->db->where('user_id', $id);
      $query=$this->db->update('user', $user_password);

      if($query)
      {
        return true;
      }
      else
      {
        return false;
      }
      
    }

}

?>