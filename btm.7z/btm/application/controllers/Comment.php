<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* User Controller Class */

class Comment extends CI_Controller {

	/* Function for Construct Model  Classes */

	public function __construct()
	{
  		parent::__construct();
  		$this->load->model(array('task_model','comment_model'));
	}

	/* Function To INSERT a COMMENT into 'comments' Table */

	public function insert_comment()
	{

		$publisher_id=$this->session->userdata('user_id');
		$publisher_name=$this->session->userdata('name');
		$publisher_role=$this->session->userdata('user_role');
		
		$type="comment";

		$id=$this->input->post('task_id');

		date_default_timezone_set('Asia/Calcutta');

      	$comment=array(
      		'type'=>$type,
      		'comment'=>$this->input->post('comment'),
      		'publisher_id'=>$publisher_id,
      		'publisher_name'=>$publisher_name,
      		'publisher_role'=>$publisher_role,
      		'task_id'=>$id,
      		'assigned_to'=>$this->input->post('to'),
      		'current'=>$this->input->post('to'),
      		'at'=>date('d-m-Y H:i:s')
        	);

		$insert=$this->comment_model->insert($comment);
		$report['task']=$this->task_model->fetch_task($id);
        $report['cmt']=$this->comment_model->get_comment($id);
		$this->load->view('task_view', $report);
        $this->load->view('comments', $report);
	}

}

?>
