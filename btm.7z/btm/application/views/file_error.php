<html>
  <head>
    <title>Upload Form
    </title>
  </head>
  <!-- Calling Header From Views/Templates Path -->
  <?php $this->load->view('templates/header'); ?>
  <body>
    <?php $role=$this->session->userdata('user_role'); ?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <?php echo $error; ?>
          <h1>You will be redirect in 4 seconds..
          </h1>
          <?php header("Refresh:4;url=".base_url()."assign"); ?>
        </div>
      </aside>
    </article>      
  </body>
</html>
<html>
  <head>
    <title>Upload Form
    </title>
  </head>
  <body>
    <?php $this->load->view('templates/header'); ?>
    <article>
      <aside class="left-panel">
        <div class="brand-logo">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <div class="company-name">AGT India
                </div>
                <div class="company-app">Task Management
                </div>
              </div>
            </div>  
          </div>
        </div>
        <div class="navigation">
          <ul>
            <li class="active">
              <a href="<?php echo site_url(); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-user">
                  </i>
                </span>
                <span class="navigation-label">Dashboard
                </span>
              </a>
            </li>
            <li>
              <a href="<?php echo site_url('assign'); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-user">
                  </i>
                </span>
                <span class="navigation-label">Assign Task
                </span>
              </a>
            </li>
            <?php if($role=='admin' || $role=='manager') { ?>
            <li>
              <a href="<?php echo site_url('register'); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-plus">
                  </i>
                </span>
                <span class="navigation-label">Add Employee
                </span>
              </a>
            </li>
            <?php } if($role=='admin') { ?>
            <li>
              <a href="<?php echo site_url('report'); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-signal">
                  </i>
                </span>
                <span class="navigation-label">Report
                </span>
              </a>
            </li>
            <?php } ?>
            <li>
              <a href="<?php echo site_url('profile'); ?>">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-user">
                  </i>
                </span>
                <span class="navigation-label">Profile
                </span>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url('logout'); ?>" onclick="return confirm('Are you sure to logout?');">
                <span class="navigation-icon">
                  <i class="glyphicon glyphicon-user">
                  </i>
                </span>
                <span class="navigation-label">Logout
                </span>
              </a>
            </li>
          </ul>
        </div>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <?php echo $error; ?>
          <h1>You will be redirect in 4 seconds..
          </h1>
          <?php header("Refresh:4;url=".base_url()."assign"); ?>
        </div>
      </aside>
    </article>      
  </body>
</html>
