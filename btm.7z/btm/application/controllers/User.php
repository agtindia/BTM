<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/* User Controller Class */

class User extends CI_Controller {

/* Function for Construct Model */

public function __construct()
{

  parent::__construct();
  $this->load->model(array('user_model','comment_model','assign_model'));

}

/* Function for Load (View) Login Form */

public function index()
{
	$this->load->helper('form');
	$this->load->view("login.php");
}

/* Register User Controller Function */

public function register_user()
{

  $user=array(
      'name'=>$this->input->post('name'),
      'user_name'=>$this->input->post('user_name'),
      'user_email'=>$this->input->post('user_email'),
      'user_password'=>md5($this->input->post('user_password')),
      'user_role'=>$this->input->post('user_role'),
      'user_mobile'=>$this->input->post('user_mobile')
        );
        print_r($user);

  $email_check=$this->user_model->email_check($user['user_email']);

  if($email_check)
  {
    $this->user_model->register_user($user);

    // Send Mail To User

      $email_current=$this->session->userdata('user_email');

      $config = array('mailtype'=>'html');
      $this->load->library('email', $config);
      $this->email->set_newline("\r\n");    
      $this->email->from($email_current,'Register (Task Management System)'); 
      $this->email->to($email_current);
      $this->email->subject('New Task'); 
      $this->email->message($publisher_name.' have Added New '.$user['user_role'].' , '.$user['name'].' ... Click <a href=http://btmagt.agtindia.co.in/user>Here</a> To View');
      $this->email->send();

    $this->session->set_flashdata('success_msg', 'Employee Added Successfully...');
    redirect('register');
  }
  else
  {
    $this->session->set_flashdata('error_msg', 'Employee Already Exist.');
    redirect('register');
  }

}

/* View Register Form */

public function register_view()
{
  $data['h']=$this->user_model->fetchtable(); 
  $this->load->view("register.php",$data);      
}

/* Add New Category In 'Categories' Table */

public function add_category()
{  
  $category=array('category'=>$this->input->post('category'));
  $this->user_model->add_category($category);
  redirect('categories');
}

/* Get All Categories from 'Categories' Table */

public function categories()
{  
  $cat['cat']=$this->assign_model->get_categories();
  $this->load->view('categories',$cat);
}

/* Login User Function */

public function login_user()
{
  $user_login=array('user_name'=>$this->input->post('user_name'),
  'user_password'=>md5($this->input->post('user_password')));

      $data=$this->user_model->login_user($user_login['user_name'],$user_login['user_password']);
      if($data)
      {
        $this->session->set_userdata('user_id',$data['user_id']);
        $this->session->set_userdata('user_email',$data['user_email']);
        $this->session->set_userdata('name',$data['name']);
        $this->session->set_userdata('user_name',$data['user_name']);
        $this->session->set_userdata('user_role',$data['user_role']);
        $this->session->set_userdata('user_mobile',$data['user_mobile']);

        redirect('user');

      }
      else
      {
        $this->session->set_flashdata('error_msg', 'Invalid Username or Password.');
        redirect('login');

      }
}

/* Function for View Different Tasks for Different User Roles */

public function user_profile()
{
$name=$this->session->userdata('name');  
$data['t']=$this->user_model->data(); 
$data['a']=$this->user_model->all();     
$data['b']=$this->user_model->me();  
$data['r']=$this->user_model->resolved();
$data['er']=$this->user_model->emp_resolved($name);
$data['cm']=$this->comment_model->get($name);
$data['ca']=$this->comment_model->get_all();
$this->load->view('dashboard', $data);

}

/* User Logout Function */

public function user_logout()
{

  $this->session->sess_destroy();
  redirect('login');

}

/* Delete Tasks */

public function delete()
{
    $id=$this->input->get('id');
		$this->user_model->delete($id);
    redirect('all');
}

}

?>
