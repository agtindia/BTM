<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$user_id=$this->session->userdata('user_id');

if(isset($user_id))
{
  redirect('user');
}

?>
<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login-CI Login</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" media="screen" 
  title="no title">
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/custom.css">
</head>

<body>
<div class="container">
  <div class="login-panel panel-login panel-primary">
    <div class="panel-heading">
      <h3 class="panel-title">AGT - Task Management System</h3>
    </div>
    <div class="panel-body">
      <?php
              $log_msg= $this->session->tempdata('log_msg');
              $error_msg= $this->session->flashdata('error_msg');

                  if($log_msg){
                    ?>
      <div class="alert alert-success"> <?php echo $log_msg; ?> </div>
      <?php
                  }
                  if($error_msg){
                    ?>
      <div class="alert alert-danger"> <span class="glyphicon glyphicon-remove"></span> <?php echo $error_msg; ?> </div>
      <?php
                  }
                  ?>
      <form role="form" method="post" action="user/login_user">
        <fieldset>
          <div class="form-group"  >
            <input class="form-control" placeholder="Username" name="user_name" type="text" autofocus>
          </div>
          <div class="form-group">
            <input class="form-control" placeholder="Password" name="user_password" type="password" value="">
          </div>
          <input class="btn btn-md btn-primary btn-block" type="submit" value="Login" name="login" >
        </fieldset>
      </form>
    </div>
  </div>
</div>
</body>
</html>
