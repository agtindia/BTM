<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
foreach ($task->result() as $issue) {
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Details-Task Assign System
    </title>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
    </script>
    <script src="<?php echo base_url()  ?>/application/asset/js/tinymce/tinymce.min.js">
    </script>
    <script type="text/javascript">
      tinymce.init({
        selector: "textarea",
        plugins: "link image"
      }
                  );
    </script>
  </head>  
    <?php $this->load->view('templates/header'); ?>
  <body>
    <?php $role=$this->session->userdata('user_role'); ?>
    <?php $name=$this->session->userdata('name'); ?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <?php if($role=="employee") { if($issue->assigned_to==$name) { ?>
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register-profile info panel-primary">
                  <div class="panel-heading">
                    <div class="row">
                      <div class="col-md-6">
                        <h3 class="panel-title">
                          <i class="ace-icon fa fa-list-alt">
                          </i> Task Details
                        </h3>
                      </div>
                      <div class="col-md-6">
                        <a href="update?id=<?php echo $issue->id; ?>">
                          <button type="button" class="btn btn-warning btn-sm">
                            <span class="glyphicon glyphicon-pencil">
                            </span> Update Task
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="body">
                    <div class="table-responsive">
                      <table class="table table-bordered">
                        <tbody>
                          <tr class="bug-header">
                            <th width="15%">ID
                            </th>
                            <th width="20%" colspan="2">Title
                            </th>
                            <th width="15%">Priority
                            </th>
                            <th width="15%">Status
                            </th>
                            <th width="15%">Date Assigned
                            </th>
                          </tr>
                          <tr>
                            <td>
                              <?php echo $issue->id; ?>
                            </td>
                            <td colspan="2">
                              <?php echo $issue->title; ?>
                            </td>
                            <td>
                              <?php echo $issue->priority; ?>
                            </td>
                            <?php if($issue->status=="Resolved") { ?>
                            <td class="bg-success">
                              <?php echo $issue->status; ?>
                            </td>
                            <?php } else { ?>
                            <td>
                              <?php echo $issue->status; ?>
                            </td>
                            <?php } ?>
                            <td>
                              <?php echo $issue->time; ?>
                            </td>
                          </tr>
                          <tr>
                            <td colspan="6">
                            </td>
                          </tr>
                          <tr>
                          </tr>
                          <tr>
                            <th>Reporter
                            </th>
                            <td>
                              <?php echo $issue->assigned_by; ?>
                            </td>
                            <th>End Date
                            </th>
                            <td>
                              <?php echo $issue->end_date; ?>
                            </td>
                            <th>Begin
                            </th>
                            <td class="text-center">
                              <?php echo $issue->start; ?>
                            </td>
                          </tr>
                          <tr>
                            <th>Start Date
                            </th>
                            <td>
                              <?php echo $issue->start_date; ?>
                            </td>
                            <th>Assigned To
                            </th>
                            <td >
                              <?php echo $issue->assigned_to; ?>
                            </td>
                            <th>Finish
                            </th>
                            <td class="text-center">
                              <?php echo $issue->end; ?>
                            </td>
                          </tr>
                          <tr>
                            <th>Due Date
                            </th>
                            <td>
                              <?php echo $issue->due_date; ?>
                            </td>
                            <th colspan="2" class="text-center">Total Hours Taken
                            </th>
                            <?php $total=$issue->working_hours; ?>
                            <?php if($total!=NULL ) { ?>
                            <td colspan="2" class="text-center bg-success">
                              <?php echo $total; ?>
                            </td>
                            <?php } else { ?>
                            <td colspan="2" class="text-center bg-danger">
                              <?php echo "Not Finished"; ?>
                            </td>
                            <?php } ?>
                          </tr>
                          <tr>
                            <td colspan="6">
                            </td>
                          </tr>
                          <tr>
                          </tr>
                          <tr>
                            <th>Attachments
                            </th>
                            <td colspan="5">
                              <i class="fa fa-paperclip" aria-hidden="true">
                              </i>
                              <a href="<?php echo base_url() ?>uploads/<?php echo $issue->task_file; ?>">
                                <?php echo $issue->task_file; ?>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <th>Description
                            </th>
                            <td colspan="5">
                              <?php echo $issue->description; ?>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php } else { ?>
            <h1>You are not allowed to view this task..
            </h1>
          <?php } } else { ?>
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register-profile info panel-primary">
                  <div class="panel-heading">
                    <div class="row">
                      <div class="col-md-6">
                        <h3 class="panel-title">
                          <i class="ace-icon fa fa-list-alt">
                          </i> Task Details
                        </h3>
                      </div>
                      <div class="col-md-6">
                        <a href="update?id=<?php echo $issue->id; ?>">
                          <button type="button" class="btn btn-warning btn-sm">
                            <span class="glyphicon glyphicon-pencil">
                            </span> Update Task
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="body">
                    <div class="table-responsive">
                      <table class="table table-bordered">
                        <tbody>
                          <tr class="bug-header">
                            <th width="15%">ID
                            </th>
                            <th width="20%" colspan="2">Title
                            </th>
                            <th width="15%">Priority
                            </th>
                            <th width="15%">Status
                            </th>
                            <th width="15%">Date Assigned
                            </th>
                          </tr>
                          <tr>
                            <td>
                              <?php echo $issue->id; ?>
                            </td>
                            <td colspan="2">
                              <?php echo $issue->title; ?>
                            </td>
                            <td>
                              <?php echo $issue->priority; ?>
                            </td>
                            <?php if($issue->status=="Resolved") { ?>
                            <td class="bg-success">
                              <?php echo $issue->status; ?>
                            </td>
                            <?php } else { ?>
                            <td>
                              <?php echo $issue->status; ?>
                            </td>
                            <?php } ?>
                            <td>
                              <?php echo $issue->time; ?>
                            </td>
                          </tr>
                          <tr>
                            <td colspan="6">
                            </td>
                          </tr>
                          <tr>
                          </tr>
                          <tr>
                            <th>Reporter
                            </th>
                            <td>
                              <?php echo $issue->assigned_by; ?>
                            </td>
                            <th>End Date
                            </th>
                            <td>
                              <?php echo $issue->end_date; ?>
                            </td>
                            <th>Begin
                            </th>
                            <td class="text-center">
                              <?php echo $issue->start; ?>
                            </td>
                          </tr>
                          <tr>
                            <th>Start Date
                            </th>
                            <td>
                              <?php echo $issue->start_date; ?>
                            </td>
                            <th>Assigned To
                            </th>
                            <td >
                              <?php echo $issue->assigned_to; ?>
                            </td>
                            <th>Finish
                            </th>
                            <td class="text-center">
                              <?php echo $issue->end; ?>
                            </td>
                          </tr>
                          <tr>
                            <th>Due Date
                            </th>
                            <td>
                              <?php echo $issue->due_date; ?>
                            </td>
                            <th colspan="2" class="text-center">Total Hours Taken
                            </th>
                            <?php $total=$issue->working_hours; ?>
                            <?php if($total!=NULL ) { ?>
                            <td colspan="2" class="text-center bg-success">
                              <?php echo $total; ?>
                            </td>
                            <?php } else { ?>
                            <td colspan="2" class="text-center">
                              <?php echo "Not Finished"; ?>
                            </td>
                            <?php } ?>
                          </tr>
                          <tr>
                            <td colspan="6">
                            </td>
                          </tr>
                          <tr>
                          </tr>
                          <tr>
                            <th>Attachments
                            </th>
                            <td colspan="5">
                              <i class="fa fa-paperclip" aria-hidden="true">
                              </i>
                              <a href="<?php echo base_url() ?>uploads/<?php echo $issue->task_file; ?>">
                                <?php echo $issue->task_file; ?>
                              </a>
                            </td>
                          </tr>
                          <tr>
                            <th>Description
                            </th>
                            <td colspan="5">
                              <?php echo $issue->description; ?>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
    <?php } } ?>
