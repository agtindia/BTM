<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8">
    </script>  
    <script type="text/javascript" src ="<?php echo base_url(); ?>js/jquery.tabletoCSV.js">
    </script>
    <script>
      $(function(){
        $("#export").click(function(){
          $("#export_table").tableToCSV();
        });
      });
      $(document).ready(function () {
        $("#ckbCheckAll").click(function () {
          $(".checkBoxClass").each(function(){
            if($(this).prop("checked", true)) {
              $(this).prop("checked", false);
            }
            else {
              $(this).prop("checked", true);
            }
          });
        });
      });
    </script>
  </head>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <!-- Storing User Role From Session Data In Role Variable -->
    <?php $role=$this->session->userdata('user_role'); ?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <!-- View Tasks Assigned To Current User -->
          <div class="row">
            <div class="col-md-8">
            </div>
            <div class="col-md-4">
              <?php if($role=="employee") { ?>
              <form method="GET" action="search_task" autocomplete="off">
                <?php } else { ?>
                <form method="GET" action="search" autocomplete="off">
                  <?php } ?>
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search..." name="q">
                    <div class="input-group-btn">
                      <button class="btn btn-warning" type="submit">
                        <i class="glyphicon glyphicon-search">
                        </i>
                      </button>
                    </div>
                  </div>
                </form>
                </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="panel-register info panel-primary">
                  <div class="panel-heading">
                    <h3 class="panel-title">Assigned To Me
                    </h3> 
                    <a href="to" class="view-all-btn">View All
                    </a>  
                  </div>
                  <div class="body text-center">
                    <div class="table-responsive">
                      <table id="export_table" class="table table-bordered">
                        <tr>
                          <th class="text-center">ID
                          </th>
                          <th class="text-center">Title
                          </th>
                          <th class="text-center">At
                          </th>
                          <th class="text-center">By
                          </th>
                          <th class="text-center">Status
                          </th>
                          <th class="text-center">Due Date
                          </th>
                          <th class="text-center">
                          </th>
                        </tr>
                        <?php foreach ($t->result() as $task) { $status=$task->status; ?>
                        <tr>
                          <td>
                            <?php echo $task->id; ?>
                          </td>
                          <td>
                            <a href="task_view?id=<?php echo $task->id ?>">
                              <?php echo $task->title; ?>
                            </a>
                          </td>
                          <td>
                            <?php echo $task->time; ?>
                          </td>
                          <td>
                            <?php echo $task->assigned_by; ?>
                          </td>
                          <td>
                            <?php  
if($status=='New') 
{ 
echo '<span class=task-new>'.$status.'</span>'; 
} 
elseif($status=='Ongoing') 
{ 
echo '<span class=task-pending>'.$status.'</span>'; 
}
elseif($status=='Closed') 
{ 
echo '<span class=task-closed>'.$status.'</span>'; 
}
else 
{ 
echo '<span class=task-resolved>'.$status.'</span>'; 
} 
?>
                          </td>
                          <td>
                            <?php echo $task->due_date; ?>
                          </td>
                          <td>
                            <a href="update?id=<?php echo $task->id ?>">
                              <button type="button" name="update"> 
                                <i class="fa fa-pencil pencil grey">
                                </i>
                              </button>
                            </a>
                        </td>
                      </tr>
                    <?php } ?>
                    </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      </aside>
    </article>
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
</html>
