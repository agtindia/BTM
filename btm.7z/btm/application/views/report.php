<?php 
defined('BASEPATH') OR exit('No direct script access allowed');  
$user_id=$this->session->userdata('user_id');
$role=$this->session->userdata('user_role');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Task - Task Assign System
    </title>  
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript" charset="utf-8">
    </script>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()  ?>/css/task.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js">
    </script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js">
    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js">
    </script>
    <script>
      $( function() {
        $( "#datepicker" ).datepicker({
          dateFormat: 'dd/mm/yy' }
                                     ).val();
        $( "#datepicker1" ).datepicker({
          dateFormat: 'dd/mm/yy' }
                                      ).val();
        $( "#datepicker2" ).datepicker({
          dateFormat: 'dd/mm/yy' }
                                      ).val();
      }
       );
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
    </script>
    <script src="<?php echo base_url()  ?>/application/asset/js/tinymce/tinymce.min.js">
    </script>
    <script type="text/javascript">
      tinymce.init({
        selector: "textarea",
        plugins: "link image"
      }
                  );
    </script>
  </head>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">
          <h4>Coming Soonn....
          </h4>
        </div>
      </aside>
    </article>
  </body>
</html>
