<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$user_id=$this->session->userdata('user_id');

$name=$this->session->userdata('name');

$role=$this->session->userdata('user_role');

if(!$user_id){

  redirect('login');
}

?>

<head>

<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>css/bootstrap.min.css">

<link rel="shortcut icon" type="image/png" href="<?php echo base_url() ?>images/task_favicon.ico">

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/css/custom.css">

<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/css/responsive.css">

<script type="text/javascript" src="https://rawgit.com/wenzhixin/bootstrap-show-password/master/bootstrap-show-password.js">

</script>

<!--  Tootltip Script-->
<script>
    $(document).ready(function(){
      $('[data-toggle="tooltip"]').tooltip();   
    });
</script>

</head>

<body>

<header>
	<div class="container-fluid">
    	<div class="row">
        	<aside class="col-md-8"></aside>
            <aside class="col-md-4">
            	<ul class="notify-bar">
                	<li>
                    	<a href="#" class="profile-photo">
                            <i class="fa fa-user-circle" style="font-size: 30px" aria-hidden="true"></i>
                        </a>
                         <div class="dropdown profile-details">
                         	<div class="welcome-profile">
                                <span class="profile-icon">
                                	<i class="fa fa-user-circle" style="font-size: 50px" aria-hidden="true"></i>
                                </span>
                                <span class="profile-name">Hello <?php echo $name; ?></span>
                                <span class="profile-designation"><?php echo $role; ?></span>
                            </div>
                        </div>
                    </li>
                </ul>
            </aside>
        </div>
    </div>
</header>
