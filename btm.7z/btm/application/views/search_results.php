<!-- Search Results Page -->
<?php $this->load->view('templates/header'); ?>
<?php $role=$this->session->userdata('user_role'); ?>
<article>
  <aside class="left-panel">
    <?php $this->load->view('templates/left_bar'); ?>
  </aside>
  <aside class="content-panel">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <?php $role=$this->session->userdata('user_role'); ?>
          <?php if($role=="employee") { ?> 
          <form method="GET" action="search_task" autocomplete="off">
            <?php } else { ?>
            <form method="GET" action="search" autocomplete="off"> 
              <?php } ?>
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search..." name="q">
                <div class="input-group-btn">
                  <button class="btn btn-warning btn-search" type="submit">
                    <i class="glyphicon glyphicon-search">
                    </i>
                  </button>
                </div>	
              </div>
            </form>
            </div>
        </div>
        <div class="table-responsive">
          <table class="table table-bordered text-center">
            <tr>
              <th class="text-center">ID
              </th>
              <th class="text-center">Created At
              </th>
              <th class="text-center">Title
              </th>
              <th class="text-center">Assigned By
              </th>
              <th class="text-center">Assigned To
              </th>
              <th class="text-center">Start Date
              </th>
              <th class="text-center">Due Date
              </th>
              <th class="text-center">End Date
              </th>
            </tr>
            <?php foreach($rows->result() as $task) { ?> 
            <tr class="link bg-success">
              <td>
                <a href="task_view?id=<?php echo $task->id ?>">
                  <?php echo $task->id; ?>
                </a>
              </td>
              <td>
                <?php echo $task->time; ?>
              </td>
              <td>
                <a href="task_view?id=<?php echo $task->id ?>">
                  <?php echo $task->title; ?>
                </a>
              </td>              
              <td>
                <?php echo $task->assigned_by; ?>
              </td>
              <td>
                <?php echo $task->assigned_to; ?>
              </td> 
              <td>
                <?php echo $task->start_date; ?>
              </td>  
              <td>
                <?php echo $task->due_date; ?>
              </td>    
              <td>
                <?php echo $task->end_date; ?>
              </td>
            </tr>
            <?php } ?>
          </table>
        </div>
      </div>
      </aside>
    </article>
