<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$user_id=$this->session->userdata('user_id');
if(!$user_id){
redirect('login');
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Task Assign System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  </head>
    <!-- Calling Header From Views/Templates Path -->
    <?php $this->load->view('templates/header'); ?>
  <body>
    <!-- Storing User Role From Session Data In Role Variable -->
    <?php $role=$this->session->userdata('user_role'); $this->load->helper('form'); ?>
    <article>
      <aside class="left-panel">
        <?php $this->load->view('templates/left_bar'); ?>
      </aside>
      <aside class="content-panel">
        <div class="container-fluid">

          <?php if($role=="admin") { ?>

            <div class="row">

              <div class="col-md-6">
                <div class="form-group">                        
                  <div class="table-responsive">
                    <table id="example" class="table table-bordered">                       
                      <tr>
                        <th class="text-center">S.No.</th>
                        <th class="text-center">Category</th>
                      </tr>
                      <?php foreach ($cat->result() as $cat) { ?>
                      <tr>
                        <td><?php echo $cat->id; ?> </td>
                        <td><?php echo $cat->category; ?></td>
                      </tr>                    
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>

            <div class="col-md-6">
              <div class="panel-register-profile info panel-primary">
                <div class="panel-heading">
                  <h3 class="panel-title">Add New Category</h3>
                </div>
                <div class="panel-body">
                  <form role="form" method="post" action="user/add_category" enctype="multipart/form-data" autocomplete="off" >
                    <div class="form-group">
                        <input class="form-control" name="category" type="text" placeholder="New Category..." required="required"> 
                    </div>
                    <div class="form-group">                    
                        <div class="row">
                          <div class="col-md-10">
                          </div>
                          <div class="col-md-2">
                            <input class="btn btn-primary btn-block" type="submit" value="+ Add" name="update">
                          </div>
                        </div>
                    </div>
                  </form>
                </div>
            </div>

            </div>

            <?php } else { ?>
              <h1>Permission Denied..</h1>
            <?php } ?>

      </aside>
    </article>
    <!-- Calling Footer From Views/Templates Path -->
    <?php $this->load->view('templates/footer'); ?>
  </body>
</html>


